
// Employee data types
export interface Employee {
  id: string;
  name: string;
  username: string;
  password: string;
  subjects: string[];
  stage: string;
  tasks: {
    whatsapp: number;
    reviewContent: number;
    paperSummaries: number;
    exams: number;
    modelExams: number;
    teacherReport: number;
  };
  overall: number;
  rating: "Hero" | "Steady" | "Low";
  warnings: string[];
  warningsCount: number;
  dailyTasks: DailyTaskDetails;
  monthlyTasks: MonthlyTasks;
  periodDelayMinutes: number;
  dailyDelays: number[];
  isDayOff: boolean;
  workingHours: number;
  delayMinutes: number;
  isAbsent: boolean;
  whatsappDailyData: WhatsappDailyData[];
  examsPerStage: Record<string, ExamData>;
  summariesPerStage: Record<string, SummaryData>;
}

export interface DailyTaskDetails {
  whatsappChats: number;
  summariesWritten: number;
  contentReviewed: number;
  examsRecorded: number;
  modelExamsRecorded: number;
  teacherReports: number;
  percentages: {
    whatsapp: number;
    reviewContent: number;
    paperSummaries: number;
    exams: number;
    modelExams: number;
    teacherReport: number;
  };
}

export interface MonthlyTasks {
  whatsappChats: number;
  summariesWritten: number;
  contentReviewed: number;
  examsRecorded: number;
  modelExamsRecorded: number;
  teacherReports: number;
}

export interface WhatsappDailyData {
  date: string;
  loginChats: number;
  logoutChats: number;
  totalChats: number;
  rating: number;
  isLocked: boolean;
}

export interface ExamData {
  exams: ExamItem[];
  modelExams: ExamItem[];
}

export interface SummaryData {
  paperSummaries: SummaryItem[];
  finalPaperSummary: SummaryItem[];
}

export interface ExamItem {
  id: string;
  completed: boolean;
  file: string | null;
  fileName?: string;
}

export interface SummaryItem {
  id: string;
  completed: boolean;
  file: string | null;
  fileName?: string;
}

export interface SubjectSchedule {
  subject: string;
  sessions: number;
  dates: string[];
}

export interface TaskSettings {
  modelExamsCount: number;
  finalSummaryCount: number;
  whatsappChatsCount: number;
  contentReviewCount: number;
  examsRecordedCount: number;
  teacherReportsCount: number;
}

export interface EditRequest {
  employeeName: string;
  date: string;
  reason: string;
  attachment: string | null;
  status: "pending" | "approved" | "rejected";
}

export interface Notification {
  employeeName: string;
  message: string;
  isRead: boolean;
}

// New types for data entry functionality
export type EmployeeFileType = 'exam' | 'modelExam' | 'paperSummary' | 'finalPaperSummary';

export interface FileUpload {
  id: string;
  employeeId: string;
  employeeName: string;
  fileType: EmployeeFileType;
  fileName: string;
  fileURL: string;
  subject: string;
  stage: string;
  timestamp: number;
  viewed: boolean;
  processed: boolean;
}
