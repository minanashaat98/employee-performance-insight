
// Firebase Configuration
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";

// Firebase configuration
// يمكنك استبدال هذه القيم بمعلومات مشروع Firebase الخاص بك
const firebaseConfig = {
  apiKey: "AIzaSyBCH-ReP-ycUy7rzOmYUoBMF7GgRgZ03vk",
  authDomain: "employee-management-demo-app.firebaseapp.com",
  projectId: "employee-management-demo-app",
  storageBucket: "employee-management-demo-app.appspot.com",
  messagingSenderId: "514751785013",
  appId: "1:514751785013:web:b25e4b6c71828d9e6fb01e"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize services
export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);

export default app;
