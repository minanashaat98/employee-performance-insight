
import { 
  collection, 
  doc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  query, 
  where,
  DocumentData,
  QueryConstraint 
} from "firebase/firestore";
import { db } from "./config";
import { useCallback } from "react";

export const useFirestore = () => {
  // إضافة مستند جديد مع معرف محدد
  const addDocument = useCallback(async (collectionName: string, id: string, data: any) => {
    try {
      const docRef = doc(db, collectionName, id);
      await setDoc(docRef, { ...data, id });
      return { id, ...data };
    } catch (error) {
      console.error("Error adding document: ", error);
      throw error;
    }
  }, []);

  // تحديث مستند موجود
  const updateDocument = useCallback(async (collectionName: string, id: string, data: any) => {
    try {
      const docRef = doc(db, collectionName, id);
      await updateDoc(docRef, data);
      return { id, ...data };
    } catch (error) {
      console.error("Error updating document: ", error);
      throw error;
    }
  }, []);

  // حذف مستند
  const deleteDocument = useCallback(async (collectionName: string, id: string) => {
    try {
      const docRef = doc(db, collectionName, id);
      await deleteDoc(docRef);
      return true;
    } catch (error) {
      console.error("Error deleting document: ", error);
      throw error;
    }
  }, []);

  // الحصول على مستندات مجموعة
  const getCollection = useCallback(async (collectionName: string, constraints: QueryConstraint[] = []) => {
    try {
      const collectionRef = collection(db, collectionName);
      const q = constraints.length > 0 ? query(collectionRef, ...constraints) : collectionRef;
      const querySnapshot = await getDocs(q);
      
      const docs: DocumentData[] = [];
      querySnapshot.forEach((doc) => {
        docs.push({ id: doc.id, ...doc.data() });
      });
      
      return docs;
    } catch (error) {
      console.error("Error getting collection: ", error);
      throw error;
    }
  }, []);

  return {
    addDocument,
    updateDocument,
    deleteDocument,
    getCollection,
  };
};
