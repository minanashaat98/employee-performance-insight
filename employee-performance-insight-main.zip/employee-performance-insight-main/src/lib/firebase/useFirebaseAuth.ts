
import { useCallback } from "react";
import { 
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as firebaseSignOut,
  sendPasswordResetEmail,
  updatePassword,
  User,
  EmailAuthProvider,
  reauthenticateWithCredential
} from "firebase/auth";
import { auth } from "./config";

export const useFirebaseAuth = () => {
  // تسجيل الدخول باستخدام البريد الإلكتروني وكلمة المرور
  const login = useCallback(async (email: string, password: string) => {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      return userCredential.user;
    } catch (error) {
      console.error("Error signing in: ", error);
      throw error;
    }
  }, []);

  // إنشاء مستخدم جديد باستخدام البريد الإلكتروني وكلمة المرور
  const register = useCallback(async (email: string, password: string) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      return userCredential.user;
    } catch (error) {
      console.error("Error creating user: ", error);
      throw error;
    }
  }, []);

  // تسجيل الخروج
  const signOut = useCallback(async () => {
    try {
      await firebaseSignOut(auth);
      return true;
    } catch (error) {
      console.error("Error signing out: ", error);
      throw error;
    }
  }, []);

  // إعادة تعيين كلمة المرور
  const resetPassword = useCallback(async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email);
      return true;
    } catch (error) {
      console.error("Error resetting password: ", error);
      throw error;
    }
  }, []);

  // تغيير كلمة المرور للمستخدم الحالي
  const changePassword = useCallback(async (currentPassword: string, newPassword: string) => {
    try {
      const user = auth.currentUser;
      if (!user || !user.email) {
        throw new Error("No authenticated user found");
      }
      
      // إعادة المصادقة قبل تغيير كلمة المرور
      const credential = EmailAuthProvider.credential(user.email, currentPassword);
      await reauthenticateWithCredential(user, credential);
      
      // تحديث كلمة المرور
      await updatePassword(user, newPassword);
      return true;
    } catch (error) {
      console.error("Error changing password: ", error);
      throw error;
    }
  }, []);

  // الحصول على المستخدم الحالي
  const getCurrentUser = useCallback((): User | null => {
    return auth.currentUser;
  }, []);

  return {
    login,
    register,
    signOut,
    resetPassword,
    changePassword,
    getCurrentUser
  };
};
