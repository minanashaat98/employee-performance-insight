
import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth } from './config';
import { useFirebaseAuth } from './useFirebaseAuth';
import { useFirestore } from './useFirestore';
import { useFirebaseStorage } from './useFirebaseStorage';
import { useAppStore } from '../store';

interface FirebaseContextType {
  user: User | null;
  loading: boolean;
  error: string | null;
  auth: ReturnType<typeof useFirebaseAuth>;
  firestore: ReturnType<typeof useFirestore>;
  storage: ReturnType<typeof useFirebaseStorage>;
}

const FirebaseContext = createContext<FirebaseContextType | null>(null);

export const FirebaseProvider: React.FC<{children: ReactNode}> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const firebaseAuth = useFirebaseAuth();
  const firestore = useFirestore();
  const storage = useFirebaseStorage();
  
  const { login: storeLogin } = useAppStore(state => ({ login: state.login }));

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, 
      (user) => {
        setUser(user);
        setLoading(false);
        
        // إذا كان هناك مستخدم مسجل، يمكن تحديث حالة التطبيق هنا
        if (user) {
          // مثال: يمكن استدعاء دالة تحديث حالة الزستاند هنا
          console.log("User is signed in:", user.uid);
        }
      },
      (error) => {
        setError(error.message);
        setLoading(false);
      }
    );
    
    return () => unsubscribe();
  }, []);

  const value: FirebaseContextType = {
    user,
    loading,
    error,
    auth: firebaseAuth,
    firestore,
    storage
  };

  return (
    <FirebaseContext.Provider value={value}>
      {children}
    </FirebaseContext.Provider>
  );
};

export const useFirebase = () => {
  const context = useContext(FirebaseContext);
  if (context === null) {
    throw new Error('useFirebase must be used within a FirebaseProvider');
  }
  return context;
};
