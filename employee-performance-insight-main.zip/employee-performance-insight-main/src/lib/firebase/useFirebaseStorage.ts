
import { useCallback } from "react";
import { ref, uploadBytes, getDownloadURL, deleteObject } from "firebase/storage";
import { storage } from "./config";

export const useFirebaseStorage = () => {
  // رفع ملف
  const uploadFile = useCallback(async (file: File, path: string) => {
    try {
      const storageRef = ref(storage, path);
      const snapshot = await uploadBytes(storageRef, file);
      const downloadURL = await getDownloadURL(snapshot.ref);
      
      return {
        path,
        url: downloadURL,
        fileName: file.name
      };
    } catch (error) {
      console.error("Error uploading file: ", error);
      throw error;
    }
  }, []);

  // حذف ملف
  const deleteFile = useCallback(async (path: string) => {
    try {
      const storageRef = ref(storage, path);
      await deleteObject(storageRef);
      return true;
    } catch (error) {
      console.error("Error deleting file: ", error);
      throw error;
    }
  }, []);

  // الحصول على URL للتحميل
  const getFileUrl = useCallback(async (path: string) => {
    try {
      const storageRef = ref(storage, path);
      const url = await getDownloadURL(storageRef);
      return url;
    } catch (error) {
      console.error("Error getting file URL: ", error);
      throw error;
    }
  }, []);

  return {
    uploadFile,
    deleteFile,
    getFileUrl
  };
};
