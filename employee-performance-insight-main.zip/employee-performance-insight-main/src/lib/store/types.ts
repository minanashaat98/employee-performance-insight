
import { 
  Employee, 
  EditRequest,
  Notification,
  SubjectSchedule,
  TaskSettings,
  FileUpload
} from '../types';

export interface PersistState {
  employees: Employee[];
  stages: string[];
  subjects: string[];
  taskSettings: TaskSettings;
  editRequests: EditRequest[];
  notifications: Notification[];
  subjectSchedules: SubjectSchedule[];
  currentUser: string | null;
  isAdmin: boolean;
  isDataEntry: boolean;
  fileUploads: FileUpload[];
}

// Export TaskSettings type to make it available to taskSlice.ts
export type { TaskSettings };

export interface AuthSlice {
  login: (username: string, password: string) => boolean;
  logout: () => void;
}

export interface EmployeeSlice {
  addEmployee: (employee: Omit<Employee, 'id'>) => void;
  updateEmployee: (employeeId: string, data: Partial<Employee>) => void;
  deleteEmployee: (employeeId: string) => void;
  updateWhatsappData: (
    employeeId: string, 
    date: string, 
    loginChats: number, 
    logoutChats: number, 
    totalChats: number, 
    rating: number
  ) => void;
  updateExamStatus: (
    employeeId: string,
    stage: string,
    type: 'exams' | 'modelExams',
    index: number,
    completed: boolean
  ) => void;
  updateSummaryStatus: (
    employeeId: string,
    stage: string,
    type: 'paperSummaries' | 'finalPaperSummary',
    index: number,
    completed: boolean
  ) => void;
  uploadExamFile: (
    employeeId: string,
    stage: string,
    type: 'exams' | 'modelExams',
    index: number,
    fileURL: string,
    fileName: string
  ) => void;
  uploadSummaryFile: (
    employeeId: string,
    stage: string,
    type: 'paperSummaries' | 'finalPaperSummary',
    index: number,
    fileURL: string,
    fileName: string
  ) => void;
}

export interface StageSlice {
  addStage: (stageName: string) => void;
  updateStage: (oldStageName: string, newStageName: string) => void;
  deleteStage: (stageName: string) => boolean;
}

export interface SubjectSlice {
  addSubject: (subjectName: string) => void;
  updateSubject: (oldSubjectName: string, newSubjectName: string) => void;
  deleteSubject: (subjectName: string) => boolean;
}

export interface ScheduleSlice {
  addSubjectSchedule: (schedule: SubjectSchedule) => void;
  updateSubjectSchedule: (subject: string, data: Partial<SubjectSchedule>) => void;
  deleteSubjectSchedule: (subject: string) => void;
}

export interface TaskSlice {
  updateTaskSettings: (settings: Partial<TaskSettings>) => void;
}

export interface EditRequestSlice {
  addEditRequest: (request: Omit<EditRequest, 'status'>) => void;
  updateEditRequestStatus: (employeeName: string, date: string, status: 'approved' | 'rejected') => void;
}

export interface NotificationSlice {
  addNotification: (notification: Omit<Notification, 'isRead'>) => void;
  markNotificationAsRead: (employeeName: string, index: number) => void;
}

export interface DataEntrySlice {
  addFileUpload: (upload: Omit<FileUpload, 'id' | 'timestamp' | 'viewed' | 'processed'>) => void;
  markFileAsViewed: (uploadId: string) => void;
  markFileAsProcessed: (uploadId: string) => void;
}

export type AppState = 
  & EmployeeSlice
  & StageSlice
  & SubjectSlice
  & ScheduleSlice
  & TaskSlice
  & AuthSlice
  & NotificationSlice
  & EditRequestSlice
  & DataEntrySlice
  & {
    employees: Employee[];
    stages: string[];
    subjects: string[];
    taskSettings: TaskSettings;
    editRequests: EditRequest[];
    notifications: Notification[];
    subjectSchedules: SubjectSchedule[];
    currentUser: string | null;
    isAdmin: boolean;
    isDataEntry: boolean;
    fileUploads: FileUpload[];
  };

export type StoreSlice<T> = (set: any, get: any) => T;
