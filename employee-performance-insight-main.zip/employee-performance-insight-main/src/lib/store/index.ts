
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { AppState, PersistState } from './types';
import { sliceEmployee } from './slices/employeeSlice';
import { sliceStage } from './slices/stageSlice';
import { sliceSubject } from './slices/subjectSlice';
import { sliceSchedule } from './slices/scheduleSlice';
import { sliceTask } from './slices/taskSlice';
import { sliceAuth } from './slices/authSlice';
import { sliceNotification } from './slices/notificationSlice';
import { sliceEditRequest } from './slices/editRequestSlice';
import { sliceDataEntry } from './slices/dataEntrySlice';
import { generateInitialEmployees } from './initialData';

// Configure persistence options
const persistConfig = {
  name: 'employee-management-storage',
  storage: {
    getItem: (name: string) => {
      const str = localStorage.getItem(name);
      if (!str) return null;
      return JSON.parse(str);
    },
    setItem: (name: string, value: unknown) => {
      localStorage.setItem(name, JSON.stringify(value));
    },
    removeItem: (name: string) => localStorage.removeItem(name),
  },
  partialize: (state: AppState): PersistState => ({
    employees: state.employees,
    stages: state.stages,
    subjects: state.subjects,
    taskSettings: state.taskSettings,
    editRequests: state.editRequests,
    notifications: state.notifications,
    subjectSchedules: state.subjectSchedules,
    currentUser: state.currentUser,
    isAdmin: state.isAdmin,
    isDataEntry: state.isDataEntry,
    fileUploads: state.fileUploads,
  }),
};

// Create the store with all slices
// Using a type assertion to fix TypeScript error with zustand persist middleware
export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Initial state
      employees: generateInitialEmployees(),
      stages: ['Senior', 'Middle', 'Junior'],
      subjects: [...new Set(generateInitialEmployees().flatMap(emp => emp.subjects))],
      taskSettings: {
        modelExamsCount: 2,
        finalSummaryCount: 1,
        whatsappChatsCount: 10,
        contentReviewCount: 5,
        examsRecordedCount: 3,
        teacherReportsCount: 1
      },
      editRequests: [],
      notifications: [],
      subjectSchedules: [],
      currentUser: null,
      isAdmin: false,
      isDataEntry: false,
      fileUploads: [],
      
      // Merge all slices
      ...sliceAuth(set, get),
      ...sliceEmployee(set, get),
      ...sliceStage(set, get),
      ...sliceSubject(set, get),
      ...sliceSchedule(set, get),
      ...sliceTask(set, get),
      ...sliceEditRequest(set, get),
      ...sliceNotification(set, get),
      ...sliceDataEntry(set, get),
    }),
    persistConfig
  ) as any
);
