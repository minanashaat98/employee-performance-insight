
import { StoreSlice, NotificationSlice } from '../types';

export const sliceNotification: StoreSlice<NotificationSlice> = (set) => ({
  addNotification: (notification) => {
    set(state => ({
      notifications: [
        ...state.notifications,
        { ...notification, isRead: false }
      ]
    }));
  },
  
  markNotificationAsRead: (employeeName, index) => {
    set(state => {
      const employeeNotifications = state.notifications
        .filter(notif => notif.employeeName === employeeName && !notif.isRead);
      
      if (index >= employeeNotifications.length) {
        return { notifications: state.notifications };
      }
      
      const globalIndex = state.notifications.findIndex(
        notif => notif === employeeNotifications[index]
      );
      
      if (globalIndex === -1) {
        return { notifications: state.notifications };
      }
      
      const notifications = [...state.notifications];
      notifications[globalIndex] = { ...notifications[globalIndex], isRead: true };
      
      return { notifications };
    });
  }
});
