
import { StoreSlice } from '../types';
import { AuthSlice } from '../types';

export const sliceAuth: StoreSlice<AuthSlice> = (set, get) => ({
  login: (username, password) => {
    const { employees } = get();
    
    // Check for admin login (hardcoded for demo)
    if (username.toUpperCase() === 'ADMIN' && password === 'admin123') {
      set({ 
        currentUser: 'admin',
        isAdmin: true,
        isDataEntry: false
      });
      return true;
    }
    
    // Check for data entry login (hardcoded for demo)
    if (username.toUpperCase() === 'DATAENTRY' && password === 'data123') {
      set({ 
        currentUser: 'dataentry',
        isAdmin: false,
        isDataEntry: true
      });
      return true;
    }
    
    // Check for employee login
    const employee = employees.find(
      emp => emp.username.toUpperCase() === username.toUpperCase() && emp.password === password
    );
    
    if (employee) {
      set({ 
        currentUser: employee.id,
        isAdmin: false,
        isDataEntry: false
      });
      return true;
    }
    
    return false;
  },
  
  logout: () => {
    set({
      currentUser: null,
      isAdmin: false,
      isDataEntry: false
    });
  },
  
  changePassword: (userId, currentPassword, newPassword) => {
    const { employees } = get();
    
    // For admin
    if (userId === 'admin' && currentPassword === 'admin123') {
      // In a real app, this would update the admin password in a database
      return true;
    }
    
    // For data entry
    if (userId === 'dataentry' && currentPassword === 'data123') {
      // In a real app, this would update the data entry password in a database
      return true;
    }
    
    // For employees
    const employeeIndex = employees.findIndex(emp => 
      emp.id === userId && emp.password === currentPassword
    );
    
    if (employeeIndex !== -1) {
      const updatedEmployees = [...employees];
      updatedEmployees[employeeIndex] = {
        ...updatedEmployees[employeeIndex],
        password: newPassword
      };
      
      set({ employees: updatedEmployees });
      return true;
    }
    
    return false;
  }
});
