
import { StoreSlice, EditRequestSlice } from '../types';

export const sliceEditRequest: StoreSlice<EditRequestSlice> = (set) => ({
  addEditRequest: (request) => {
    set(state => ({
      editRequests: [
        ...state.editRequests,
        { ...request, status: 'pending' }
      ],
      notifications: [
        ...state.notifications,
        {
          employeeName: "ADMIN",
          message: `New edit request from ${request.employeeName} for ${request.date}.`,
          isRead: false
        }
      ]
    }));
  },
  
  updateEditRequestStatus: (employeeName, date, status) => {
    set(state => {
      // Update request status
      const editRequests = state.editRequests.map(request => {
        if (request.employeeName === employeeName && request.date === date) {
          return { ...request, status };
        }
        return request;
      });
      
      // Add notification for the employee
      const notifications = [
        ...state.notifications,
        {
          employeeName,
          message: `Your edit request for ${date} has been ${status}.`,
          isRead: false
        }
      ];
      
      // If approved, unlock the whatsapp data for editing
      let employees = [...state.employees];
      
      if (status === 'approved') {
        employees = employees.map(emp => {
          if (emp.name === employeeName) {
            const whatsappDailyData = emp.whatsappDailyData.map(data => {
              if (data.date === date) {
                return { ...data, isLocked: false };
              }
              return data;
            });
            return { ...emp, whatsappDailyData };
          }
          return emp;
        });
      }
      
      return { editRequests, notifications, employees };
    });
  }
});
