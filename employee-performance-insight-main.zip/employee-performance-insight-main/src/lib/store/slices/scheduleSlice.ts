
import { StoreSlice, ScheduleSlice } from '../types';

export const sliceSchedule: StoreSlice<ScheduleSlice> = (set) => ({
  addSubjectSchedule: (schedule) => {
    set(state => {
      const existingIndex = state.subjectSchedules.findIndex(
        s => s.subject === schedule.subject
      );
      
      if (existingIndex >= 0) {
        const updatedSchedules = [...state.subjectSchedules];
        updatedSchedules[existingIndex] = schedule;
        return { subjectSchedules: updatedSchedules };
      }
      
      return { subjectSchedules: [...state.subjectSchedules, schedule] };
    });
  },
  
  updateSubjectSchedule: (subject, data) => {
    set(state => {
      const subjectSchedules = [...state.subjectSchedules];
      const index = subjectSchedules.findIndex(s => s.subject === subject);
      
      if (index !== -1) {
        subjectSchedules[index] = { ...subjectSchedules[index], ...data };
      }
      
      return { subjectSchedules };
    });
  },
  
  deleteSubjectSchedule: (subject) => {
    set(state => ({
      subjectSchedules: state.subjectSchedules.filter(s => s.subject !== subject)
    }));
  }
});
