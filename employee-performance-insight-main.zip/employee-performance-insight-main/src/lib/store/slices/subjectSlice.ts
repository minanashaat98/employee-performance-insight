
import { StoreSlice, SubjectSlice } from '../types';

export const sliceSubject: StoreSlice<SubjectSlice> = (set, get) => ({
  addSubject: (subjectName) => {
    set(state => ({ subjects: [...state.subjects, subjectName] }));
  },
  
  updateSubject: (oldSubjectName, newSubjectName) => {
    set(state => {
      // Update subjects list
      const subjects = state.subjects.map(subject => 
        subject === oldSubjectName ? newSubjectName : subject
      );
      
      // Update employees with this subject
      const employees = state.employees.map(emp => {
        if (emp.subjects.includes(oldSubjectName)) {
          return { 
            ...emp, 
            subjects: emp.subjects.map(sub => 
              sub === oldSubjectName ? newSubjectName : sub
            ) 
          };
        }
        return emp;
      });
      
      // Update subject schedules
      const subjectSchedules = state.subjectSchedules.map(schedule => {
        if (schedule.subject === oldSubjectName) {
          return { ...schedule, subject: newSubjectName };
        }
        return schedule;
      });
      
      return { subjects, employees, subjectSchedules };
    });
  },
  
  deleteSubject: (subjectName) => {
    const state = get();
    
    // Check if any employees use this subject
    if (state.employees.some(emp => emp.subjects.includes(subjectName))) {
      return false;
    }
    
    // Check if subject has a schedule
    if (state.subjectSchedules.some(schedule => schedule.subject === subjectName)) {
      return false;
    }
    
    set({ subjects: state.subjects.filter(subject => subject !== subjectName) });
    return true;
  }
});
