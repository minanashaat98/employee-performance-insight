
import { StoreSlice } from '../types';
import { DataEntrySlice } from '../types';
import { v4 as uuidv4 } from 'uuid';

export const sliceDataEntry: StoreSlice<DataEntrySlice> = (set) => ({
  addFileUpload: (upload) => {
    set(state => {
      const newUpload = {
        ...upload,
        id: uuidv4(),
        timestamp: Date.now(),
        viewed: false,
        processed: false
      };
      
      return {
        fileUploads: [...state.fileUploads, newUpload]
      };
    });
  },
  
  markFileAsViewed: (uploadId) => {
    set(state => {
      const updatedUploads = state.fileUploads.map(upload => 
        upload.id === uploadId ? { ...upload, viewed: true } : upload
      );
      
      return {
        fileUploads: updatedUploads
      };
    });
  },
  
  markFileAsProcessed: (uploadId) => {
    set(state => {
      const updatedUploads = state.fileUploads.map(upload => 
        upload.id === uploadId ? { ...upload, processed: true } : upload
      );
      
      return {
        fileUploads: updatedUploads
      };
    });
  }
});
