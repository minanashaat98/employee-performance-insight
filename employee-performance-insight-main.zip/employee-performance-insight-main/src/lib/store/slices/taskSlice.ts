
import { StoreSlice } from '../types';
import { TaskSettings } from '../types'; // Now properly imported from types

export const sliceTask: StoreSlice<TaskSlice> = (set) => ({
  updateTaskSettings: (settings: Partial<TaskSettings>) => {
    set(state => ({
      taskSettings: { ...state.taskSettings, ...settings }
    }));
  }
});

// Define TaskSlice interface
interface TaskSlice {
  updateTaskSettings: (settings: Partial<TaskSettings>) => void;
}
