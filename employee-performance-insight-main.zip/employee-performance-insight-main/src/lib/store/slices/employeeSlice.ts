
// This file is now just a re-export from the refactored structure
import { sliceEmployee } from './employee';
export { sliceEmployee };
