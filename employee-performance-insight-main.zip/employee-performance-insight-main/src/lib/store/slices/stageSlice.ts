
import { StoreSlice, StageSlice } from '../types';

export const sliceStage: StoreSlice<StageSlice> = (set, get) => ({
  addStage: (stageName) => {
    set(state => ({ stages: [...state.stages, stageName] }));
  },
  
  updateStage: (oldStageName, newStageName) => {
    set(state => {
      // Update stages list
      const stages = state.stages.map(stage => 
        stage === oldStageName ? newStageName : stage
      );
      
      // Update employees with this stage
      const employees = state.employees.map(emp => {
        if (emp.stage === oldStageName) {
          return { ...emp, stage: newStageName };
        }
        return emp;
      });
      
      return { stages, employees };
    });
  },
  
  deleteStage: (stageName) => {
    const state = get();
    
    // Check if any employees use this stage
    if (state.employees.some(emp => emp.stage === stageName)) {
      return false;
    }
    
    set({ stages: state.stages.filter(stage => stage !== stageName) });
    return true;
  }
});
