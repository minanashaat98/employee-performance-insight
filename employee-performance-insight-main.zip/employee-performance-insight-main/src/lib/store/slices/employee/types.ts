
import { Employee, ExamData, SummaryData } from '@/lib/types';

export interface EmployeeActions {
  addEmployee: (employeeData: Omit<Employee, 'id'>) => void;
  updateEmployee: (employeeId: string, data: Partial<Employee>) => void;
  deleteEmployee: (employeeId: string) => void;
}

export interface WhatsappActions {
  updateWhatsappData: (
    employeeId: string,
    date: string,
    loginChats: number,
    logoutChats: number,
    totalChats: number,
    rating: number
  ) => void;
}

export interface ExamActions {
  updateExamStatus: (
    employeeId: string,
    stage: string,
    type: 'exams' | 'modelExams',
    index: number,
    completed: boolean
  ) => void;
  uploadExamFile: (
    employeeId: string,
    stage: string,
    type: 'exams' | 'modelExams',
    index: number,
    fileURL: string,
    fileName: string
  ) => void;
}

export interface SummaryActions {
  updateSummaryStatus: (
    employeeId: string,
    stage: string,
    type: 'paperSummaries' | 'finalPaperSummary',
    index: number,
    completed: boolean
  ) => void;
  uploadSummaryFile: (
    employeeId: string,
    stage: string,
    type: 'paperSummaries' | 'finalPaperSummary',
    index: number,
    fileURL: string,
    fileName: string
  ) => void;
}
