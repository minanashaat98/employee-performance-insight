
import { v4 as uuidv4 } from 'uuid';
import { StoreSlice } from '../../types';
import { EmployeeActions } from './types';
import { Employee } from '@/lib/types';
import { initializeTasksForStages } from '@/lib/utils';
import { getCurrentPeriod, getDaysInPeriod } from '@/lib/utils';

// الحصول على عدد أيام الفترة الحالية للموظفين الجدد
const currentDate = new Date("2025-03-21");
const { periodStart, periodEnd } = getCurrentPeriod(currentDate);
const daysInPeriod = getDaysInPeriod(periodStart, periodEnd, currentDate);

export const createEmployeeActions: StoreSlice<EmployeeActions> = (set, get) => ({
  addEmployee: (employeeData) => {
    set(state => {
      const id = uuidv4();
      const employee = {
        ...employeeData,
        id,
        tasks: {
          whatsapp: 0,
          reviewContent: 0,
          paperSummaries: 0,
          exams: 0,
          modelExams: 0,
          teacherReport: 0
        },
        overall: 0,
        rating: "Low" as const,
        warnings: [],
        warningsCount: 0,
        dailyTasks: {
          whatsappChats: 0,
          summariesWritten: 0,
          contentReviewed: 0,
          examsRecorded: 0,
          modelExamsRecorded: 0,
          teacherReports: 0,
          percentages: {
            whatsapp: 0,
            reviewContent: 0,
            paperSummaries: 0,
            exams: 0,
            modelExams: 0,
            teacherReport: 0
          }
        },
        monthlyTasks: {
          whatsappChats: 0,
          summariesWritten: 0,
          contentReviewed: 0,
          examsRecorded: 0,
          modelExamsRecorded: 0,
          teacherReports: 0
        },
        periodDelayMinutes: 0,
        dailyDelays: Array(daysInPeriod).fill(0),
        isDayOff: false,
        workingHours: 0,
        delayMinutes: 0,
        isAbsent: false,
        whatsappDailyData: []
      };
      
      // تهيئة الامتحانات والملخصات
      const { examsPerStage, summariesPerStage } = initializeTasksForStages(
        employee as Employee, 
        state.taskSettings,
        state.subjectSchedules
      );
      
      employee.examsPerStage = examsPerStage;
      employee.summariesPerStage = summariesPerStage;
      
      return { employees: [...state.employees, employee as Employee] };
    });
  },
  
  updateEmployee: (employeeId, data) => {
    set(state => {
      const employees = [...state.employees];
      const index = employees.findIndex(emp => emp.id === employeeId);
      
      if (index !== -1) {
        employees[index] = { ...employees[index], ...data };
      }
      
      return { employees };
    });
  },
  
  deleteEmployee: (employeeId) => {
    set(state => ({
      employees: state.employees.filter(emp => emp.id !== employeeId)
    }));
  },
});
