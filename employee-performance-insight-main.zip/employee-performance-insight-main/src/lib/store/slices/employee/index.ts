
import { StoreSlice } from '../../types';
import { EmployeeSlice } from '../../types';
import { createEmployeeActions } from './employeeActions';
import { createWhatsappActions } from './whatsappActions';
import { createExamActions } from './examActions';
import { createSummaryActions } from './summaryActions';

export const sliceEmployee: StoreSlice<EmployeeSlice> = (set, get) => {
  // Combine all employee-related slices
  return {
    ...createEmployeeActions(set, get),
    ...createWhatsappActions(set, get),
    ...createExamActions(set, get),
    ...createSummaryActions(set, get)
  };
};
