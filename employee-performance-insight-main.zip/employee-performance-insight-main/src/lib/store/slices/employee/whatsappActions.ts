
import { StoreSlice } from '../../types';
import { WhatsappActions } from './types';

export const createWhatsappActions: StoreSlice<WhatsappActions> = (set, get) => ({
  updateWhatsappData: (employeeId, date, loginChats, logoutChats, totalChats, rating) => {
    set(state => {
      const employees = [...state.employees];
      const index = employees.findIndex(emp => emp.id === employeeId);
      
      if (index === -1) {
        return { employees };
      }
      
      const employee = { ...employees[index] };
      const existingDataIndex = employee.whatsappDailyData.findIndex(
        data => data.date === date
      );
      
      if (existingDataIndex >= 0) {
        if (employee.whatsappDailyData[existingDataIndex].isLocked) {
          return { employees };
        }
        
        const whatsappDailyData = [...employee.whatsappDailyData];
        whatsappDailyData[existingDataIndex] = {
          date,
          loginChats,
          logoutChats,
          totalChats,
          rating,
          isLocked: true
        };
        
        employee.whatsappDailyData = whatsappDailyData;
      } else {
        employee.whatsappDailyData = [
          ...employee.whatsappDailyData,
          {
            date,
            loginChats,
            logoutChats,
            totalChats,
            rating,
            isLocked: true
          }
        ];
      }
      
      employees[index] = employee;
      return { employees };
    });
  }
});
