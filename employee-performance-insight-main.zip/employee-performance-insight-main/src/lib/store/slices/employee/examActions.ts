
import { StoreSlice } from '../../types';
import { ExamActions } from './types';
import { ExamData, EmployeeFileType } from '@/lib/types';

export const createExamActions: StoreSlice<ExamActions> = (set, get) => ({
  updateExamStatus: (employeeId, stage, type, index, completed) => {
    set(state => {
      const employees = [...state.employees];
      const empIndex = employees.findIndex(emp => emp.id === employeeId);
      
      if (empIndex === -1) {
        return { employees };
      }
      
      const employee = { ...employees[empIndex] };
      const examsPerStage = { ...employee.examsPerStage };
      
      if (!examsPerStage[stage]) {
        return { employees };
      }
      
      const stageData = examsPerStage[stage] as ExamData;
      
      if (!stageData[type] || !stageData[type][index]) {
        return { employees };
      }
      
      examsPerStage[stage] = {
        ...stageData,
        [type]: [
          ...stageData[type].slice(0, index),
          { ...stageData[type][index], completed },
          ...stageData[type].slice(index + 1)
        ]
      };
      
      // Update monthly task counters
      let totalExamsCompleted = 0;
      let totalModelExamsCompleted = 0;
      
      Object.values(examsPerStage).forEach(stageData => {
        const typedStageData = stageData as ExamData;
        totalExamsCompleted += typedStageData.exams.filter(exam => exam.completed).length;
        totalModelExamsCompleted += typedStageData.modelExams.filter(exam => exam.completed).length;
      });
      
      employee.examsPerStage = examsPerStage;
      employee.monthlyTasks = {
        ...employee.monthlyTasks,
        examsRecorded: totalExamsCompleted,
        modelExamsRecorded: totalModelExamsCompleted
      };
      
      employees[empIndex] = employee;
      return { employees };
    });
  },
  
  uploadExamFile: (employeeId, stage, type, index, fileURL, fileName) => {
    const employee = get().employees.find(emp => emp.id === employeeId);
    if (!employee) return;

    // Get first subject from employee for the file upload (can be improved)
    const subject = employee.subjects.length > 0 ? employee.subjects[0] : 'General';
    
    // Create file upload record
    const fileType: EmployeeFileType = type === 'exams' ? 'exam' : 'modelExam';
    
    // Add file upload notification
    get().addFileUpload({
      employeeId,
      employeeName: employee.name,
      fileType,
      fileName,
      fileURL,
      subject,
      stage
    });
    
    set(state => {
      const employees = [...state.employees];
      const empIndex = employees.findIndex(emp => emp.id === employeeId);
      
      if (empIndex === -1) {
        return { employees };
      }
      
      const employee = { ...employees[empIndex] };
      const examsPerStage = { ...employee.examsPerStage };
      
      if (!examsPerStage[stage]) {
        return { employees };
      }
      
      const stageData = examsPerStage[stage] as ExamData;
      
      if (!stageData[type] || !stageData[type][index]) {
        return { employees };
      }
      
      examsPerStage[stage] = {
        ...stageData,
        [type]: [
          ...stageData[type].slice(0, index),
          { 
            ...stageData[type][index], 
            file: fileURL,
            fileName
          },
          ...stageData[type].slice(index + 1)
        ]
      };
      
      employee.examsPerStage = examsPerStage;
      employees[empIndex] = employee;
      return { employees };
    });
  }
});
