
import { StoreSlice } from '../../types';
import { SummaryActions } from './types';
import { SummaryData, EmployeeFileType } from '@/lib/types';

export const createSummaryActions: StoreSlice<SummaryActions> = (set, get) => ({
  updateSummaryStatus: (employeeId, stage, type, index, completed) => {
    set(state => {
      const employees = [...state.employees];
      const empIndex = employees.findIndex(emp => emp.id === employeeId);
      
      if (empIndex === -1) {
        return { employees };
      }
      
      const employee = { ...employees[empIndex] };
      const summariesPerStage = { ...employee.summariesPerStage };
      
      if (!summariesPerStage[stage]) {
        return { employees };
      }
      
      const stageData = summariesPerStage[stage] as SummaryData;
      
      if (!stageData[type] || !stageData[type][index]) {
        return { employees };
      }
      
      summariesPerStage[stage] = {
        ...stageData,
        [type]: [
          ...stageData[type].slice(0, index),
          { ...stageData[type][index], completed },
          ...stageData[type].slice(index + 1)
        ]
      };
      
      // Update monthly task counter
      let totalSummariesCompleted = 0;
      
      Object.values(summariesPerStage).forEach(stageData => {
        const typedStageData = stageData as SummaryData;
        totalSummariesCompleted += typedStageData.paperSummaries.filter(summary => summary.completed).length;
        totalSummariesCompleted += typedStageData.finalPaperSummary.filter(summary => summary.completed).length;
      });
      
      employee.summariesPerStage = summariesPerStage;
      employee.monthlyTasks = {
        ...employee.monthlyTasks,
        summariesWritten: totalSummariesCompleted
      };
      
      employees[empIndex] = employee;
      return { employees };
    });
  },
  
  uploadSummaryFile: (employeeId, stage, type, index, fileURL, fileName) => {
    const employee = get().employees.find(emp => emp.id === employeeId);
    if (!employee) return;

    // Get first subject from employee for the file upload (can be improved)
    const subject = employee.subjects.length > 0 ? employee.subjects[0] : 'General';
    
    // Create file upload record
    const fileType: EmployeeFileType = type === 'paperSummaries' ? 'paperSummary' : 'finalPaperSummary';
    
    // Add file upload notification
    get().addFileUpload({
      employeeId,
      employeeName: employee.name,
      fileType,
      fileName,
      fileURL,
      subject,
      stage
    });
    
    set(state => {
      const employees = [...state.employees];
      const empIndex = employees.findIndex(emp => emp.id === employeeId);
      
      if (empIndex === -1) {
        return { employees };
      }
      
      const employee = { ...employees[empIndex] };
      const summariesPerStage = { ...employee.summariesPerStage };
      
      if (!summariesPerStage[stage]) {
        return { employees };
      }
      
      const stageData = summariesPerStage[stage] as SummaryData;
      
      if (!stageData[type] || !stageData[type][index]) {
        return { employees };
      }
      
      summariesPerStage[stage] = {
        ...stageData,
        [type]: [
          ...stageData[type].slice(0, index),
          { 
            ...stageData[type][index], 
            file: fileURL,
            fileName
          },
          ...stageData[type].slice(index + 1)
        ]
      };
      
      employee.summariesPerStage = summariesPerStage;
      employees[empIndex] = employee;
      return { employees };
    });
  }
});
