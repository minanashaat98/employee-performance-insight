
import { v4 as uuidv4 } from 'uuid';
import { Employee, TaskSettings } from '../types';
import { 
  getCurrentPeriod,
  getDaysInPeriod,
  generatePeriodData,
  aggregatePeriodData,
  initializeTasksForStages
} from '../utils';

// Initial data
const defaultEmployeesList = [
  { name: "ROFAIDA", subjects: ["INTEGRATED-EN", "BIO-EN"], stage: "Senior" },
  { name: "KHOLOUD", subjects: ["INTEGRATED-EN", "BIO-EN"], stage: "Senior" },
  { name: "ESRAA", subjects: ["CHE-EN", "INTEGRATED-EN"], stage: "Senior" },
  { name: "KHAIRY", subjects: ["INTEGRATED-EN"], stage: "Senior" },
  { name: "HAGER", subjects: ["MATH-EN-S"], stage: "Senior" },
  { name: "ZIAD", subjects: ["MATH-EN-S"], stage: "Senior" },
  { name: "MENNA", subjects: ["BIO-AR", "INTEGRATED-AR"], stage: "Senior" },
  { name: "LATIFA", subjects: ["CHE-AR", "INTEGRATED-AR"], stage: "Senior" },
  { name: "HAGER", subjects: ["CHE-AR", "INTEGRATED-AR"], stage: "Senior" },
  { name: "SHAMS", subjects: ["PHY-AR", "INTEGRATED-AR"], stage: "Senior" },
  { name: "AMANY", subjects: ["MATH-AR-S"], stage: "Senior" },
  { name: "YUOSSEF", subjects: ["MATH-AR-S"], stage: "Senior" },
  { name: "HEND", subjects: ["PHILOSOPHY"], stage: "Senior" },
  { name: "RASHA", subjects: ["GEOGRAPHY"], stage: "Senior" },
  { name: "HAZEM", subjects: ["HISTORY"], stage: "Senior" },
  { name: "MAHASEN", subjects: ["HISTORY"], stage: "Senior" },
  { name: "TAREK", subjects: ["ARABIC-S"], stage: "Senior" },
  { name: "RADWA", subjects: ["ARABIC-S"], stage: "Senior" },
  { name: "RODAINA", subjects: ["ENGLISH"], stage: "Junior" },
  { name: "AHMED", subjects: ["ENGLISH"], stage: "Junior" },
  { name: "MARIAM", subjects: ["ENGLISH"], stage: "Junior" },
  { name: "SAMAR", subjects: ["SCIENCE-EN"], stage: "Junior" },
  { name: "EMAN", subjects: ["SCIENCE-AR"], stage: "Junior" },
  { name: "FARAH", subjects: ["MATH-EN-M"], stage: "Middle" },
  { name: "HOSSAM", subjects: ["MATH-AR-M"], stage: "Middle" },
  { name: "KARIM", subjects: ["SOCIAL STUDIES"], stage: "Middle" },
  { name: "MINA", subjects: ["SOCIAL STUDIES"], stage: "Middle" },
  { name: "IBRAHIM", subjects: ["ARABIC-M"], stage: "Middle" },
  { name: "YUOSSEF", subjects: ["ARABIC-M"], stage: "Middle" }
];

const defaultTaskSettings: TaskSettings = {
  modelExamsCount: 2,
  finalSummaryCount: 1,
  whatsappChatsCount: 10,
  contentReviewCount: 5,
  examsRecordedCount: 3,
  teacherReportsCount: 1
};

// Generate employee data
const currentDate = new Date("2025-03-21");
const { periodStart, periodEnd } = getCurrentPeriod(currentDate);
const daysInPeriod = getDaysInPeriod(periodStart, periodEnd, currentDate);

export const generateInitialEmployees = () => {
  return defaultEmployeesList.map((emp, index) => {
    const id = uuidv4();
    const isHighPerformer = index < 5;
    const dailyData = generatePeriodData(daysInPeriod, isHighPerformer);
    const periodData = aggregatePeriodData(dailyData);
    
    const dailyTasks = {
      whatsappChats: 0,
      summariesWritten: Math.floor(Math.random() * 5),
      contentReviewed: Math.floor(Math.random() * 10),
      examsRecorded: Math.floor(Math.random() * 8),
      modelExamsRecorded: Math.floor(Math.random() * 5),
      teacherReports: Math.floor(Math.random() * 3),
      percentages: {
          whatsapp: 0,
          reviewContent: Math.floor(Math.random() * 100),
          paperSummaries: Math.floor(Math.random() * 100),
          exams: Math.floor(Math.random() * 100),
          modelExams: Math.floor(Math.random() * 100),
          teacherReport: Math.floor(Math.random() * 100)
      }
    };
    
    const monthlyTasks = {
      whatsappChats: 0,
      summariesWritten: dailyTasks.summariesWritten * daysInPeriod,
      contentReviewed: dailyTasks.contentReviewed * daysInPeriod,
      examsRecorded: dailyTasks.examsRecorded * daysInPeriod,
      modelExamsRecorded: dailyTasks.modelExamsRecorded * daysInPeriod,
      teacherReports: dailyTasks.teacherReports * daysInPeriod
    };

    // Initial employee
    const employee: Employee = {
      id,
      name: emp.name,
      username: emp.name.toUpperCase(),
      password: "123456",
      subjects: emp.subjects,
      stage: emp.stage,
      tasks: periodData.tasks,
      overall: periodData.overall,
      rating: periodData.rating,
      warnings: periodData.warnings,
      warningsCount: periodData.warningsCount,
      dailyTasks,
      monthlyTasks,
      periodDelayMinutes: periodData.periodDelayMinutes,
      dailyDelays: periodData.dailyDelays,
      isDayOff: dailyData[dailyData.length - 1]?.isDayOff || false,
      workingHours: dailyData[dailyData.length - 1]?.workingHours || 0,
      delayMinutes: dailyData[dailyData.length - 1]?.delayMinutes || 0,
      isAbsent: dailyData[dailyData.length - 1]?.isAbsent || false,
      whatsappDailyData: [],
      examsPerStage: {},
      summariesPerStage: {}
    };
    
    // Initialize exams and summaries
    const { examsPerStage, summariesPerStage } = initializeTasksForStages(
      employee, 
      defaultTaskSettings,
      [] // No schedules yet
    );
    
    employee.examsPerStage = examsPerStage;
    employee.summariesPerStage = summariesPerStage;
    
    return employee;
  });
};
