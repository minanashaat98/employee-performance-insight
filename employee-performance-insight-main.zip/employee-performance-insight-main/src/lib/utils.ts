
import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { 
  Employee, 
  DailyTaskDetails, 
  WhatsappDailyData, 
  ExamData, 
  SummaryData, 
  TaskSettings 
} from "./types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Function to generate random percentage
export function getRandomPercentage(min = 0, max = 100) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Function to generate working hours
export function getRandomWorkingHours() {
  const isRandomDelay = Math.random() < 0.5;
  if (isRandomDelay) {
      const delayMinutes = Math.floor(Math.random() * 50) + 10;
      return 8 - (delayMinutes / 60);
  }
  return Math.random() < 0.5 ? 8 : 4;
}

// Function to generate random monthly delay
export function getRandomMonthlyDelay() {
  return Math.floor(Math.random() * 201);
}

// Function to generate daily delays
export function generateDailyDelays(monthlyDelayMinutes: number, isDayOff: boolean, daysInPeriod: number) {
  const dailyDelays = Array(daysInPeriod).fill(0);
  if (isDayOff) return dailyDelays;

  let remainingDelay = monthlyDelayMinutes;
  for (let i = 0; i < daysInPeriod && remainingDelay > 0; i++) {
      const maxDelayForDay = Math.min(remainingDelay, 59);
      const delay = Math.floor(Math.random() * (maxDelayForDay + 1));
      dailyDelays[i] = delay;
      remainingDelay -= delay;
  }
  if (remainingDelay > 0) dailyDelays[daysInPeriod - 1] += remainingDelay;
  return dailyDelays;
}

// Function to calculate delay and absence
export function calculateDelay(workingHours: number, requiredHours = 8) {
  if (workingHours >= requiredHours) return { delayMinutes: 0, isAbsent: false };
  const potentialDelayHours = requiredHours - workingHours;
  if (potentialDelayHours > 1) return { delayMinutes: 0, isAbsent: true };
  const delayMinutes = Math.round(potentialDelayHours * 60);
  return { delayMinutes, isAbsent: false };
}

// Function to generate random daily task details
export function getRandomDailyTaskDetails(): DailyTaskDetails {
  return {
      whatsappChats: 0,
      summariesWritten: Math.floor(Math.random() * 5),
      contentReviewed: Math.floor(Math.random() * 10),
      examsRecorded: Math.floor(Math.random() * 8),
      modelExamsRecorded: Math.floor(Math.random() * 5),
      teacherReports: Math.floor(Math.random() * 3),
      percentages: {
          whatsapp: 0,
          reviewContent: getRandomPercentage(),
          paperSummaries: getRandomPercentage(),
          exams: getRandomPercentage(),
          modelExams: getRandomPercentage(),
          teacherReport: getRandomPercentage()
      }
  };
}

// Function to generate zeroed-out task details
export function getZeroedTaskDetails(): DailyTaskDetails {
  return {
      whatsappChats: 0,
      summariesWritten: 0,
      contentReviewed: 0,
      examsRecorded: 0,
      modelExamsRecorded: 0,
      teacherReports: 0,
      percentages: {
          whatsapp: 0,
          reviewContent: 0,
          paperSummaries: 0,
          exams: 0,
          modelExams: 0,
          teacherReport: 0
      }
  };
}

// Function to calculate warnings for tasks
export function calculateTaskWarnings(tasks: any, periodDelayMinutes: number, isDayOff: boolean) {
  const warnings = [];
  if (tasks.whatsapp < 50) warnings.push("WhatsApp");
  if (tasks.reviewContent < 50) warnings.push("Review Content");
  if (tasks.paperSummaries < 50) warnings.push("Paper Summaries");
  if (tasks.exams < 50) warnings.push("Exams");
  if (tasks.modelExams < 50) warnings.push("Model Exams");
  if (tasks.teacherReport < 50) warnings.push("Teacher Report");
  if (!isDayOff && periodDelayMinutes > 120) warnings.push("Delay");
  return warnings;
}

// Function to calculate daily task warnings
export function calculateDailyTaskWarnings(percentages: Record<string, number>) {
  return {
      whatsapp: percentages.whatsapp < 50 ? "⚠️" : "-",
      reviewContent: percentages.reviewContent < 50 ? "⚠️" : "-",
      paperSummaries: percentages.paperSummaries < 50 ? "⚠️" : "-",
      exams: percentages.exams < 50 ? "⚠️" : "-",
      modelExams: percentages.modelExams < 50 ? "⚠️" : "-",
      teacherReport: percentages.teacherReport < 50 ? "⚠️" : "-"
  };
}

// Function to calculate WhatsApp rating
export function calculateWhatsappRating(loginChats: number, logoutChats: number, totalChats: number) {
  if (totalChats === 0) return 0;
  let rating = ((totalChats - logoutChats) / totalChats) * 100;
  if (loginChats > 0.5 * totalChats) rating += 5;
  return Math.min(Math.round(rating), 100);
}

// Function to get the current period
export function getCurrentPeriod(currentDate: Date) {
  const day = currentDate.getDate();
  const month = currentDate.getMonth();
  const year = currentDate.getFullYear();

  let periodStart, periodEnd, periodMonth, periodYear;
  if (day >= 25) {
      periodStart = new Date(year, month, 25);
      const nextMonth = month === 11 ? 0 : month + 1;
      const nextYear = month === 11 ? year + 1 : year;
      periodEnd = new Date(nextYear, nextMonth, 24);
      periodMonth = nextMonth;
      periodYear = nextYear;
  } else {
      const prevMonth = month === 0 ? 11 : month - 1;
      const prevYear = month === 0 ? year - 1 : year;
      periodStart = new Date(prevYear, prevMonth, 25);
      periodEnd = new Date(year, month, 24);
      periodMonth = month;
      periodYear = year;
  }
  return { periodStart, periodEnd, periodMonth, periodYear };
}

// Function to calculate days in period
export function getDaysInPeriod(periodStart: Date, periodEnd: Date, currentDate: Date) {
  const start = new Date(periodStart);
  const end = currentDate < periodEnd ? currentDate : periodEnd;
  const diffTime = end.getTime() - start.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
  return diffDays > 0 ? diffDays : 0;
}

// Function to check if a date is in the future
export function isFutureDate(dateString: string) {
  const selectedDate = new Date(dateString);
  return selectedDate > new Date();
}

// Function to initialize Exams and Summaries tasks for each stage
export function initializeTasksForStages(employee: Employee, taskSettings: TaskSettings, subjectSchedules: any[]) {
  const employeeStages = [employee.stage];
  const examsPerStage: Record<string, ExamData> = {};
  const summariesPerStage: Record<string, SummaryData> = {};

  employeeStages.forEach(stage => {
      // Get the number of sessions for each subject the employee teaches
      const getSessionsForSubject = (subject: string) => {
          const schedule = subjectSchedules.find(s => s.subject === subject);
          return schedule ? schedule.sessions : 12; // Default to 12 if no schedule
      };
      
      const subjectSessions = employee.subjects.map(subject => getSessionsForSubject(subject));
      const maxSessions = Math.max(...subjectSessions, 12); // Use the maximum sessions or default to 12

      // Initialize Exams: Number of exams = max sessions, Model Exams = taskSettings.modelExamsCount
      examsPerStage[stage] = {
          exams: Array(maxSessions).fill(null).map((_, index) => ({
              id: `exam-${stage}-${index + 1}`,
              completed: false,
              file: null
          })),
          modelExams: Array(taskSettings.modelExamsCount).fill(null).map((_, index) => ({
              id: `model-exam-${stage}-${index + 1}`,
              completed: false,
              file: null
          }))
      };

      // Initialize Summaries: Number of summaries = max sessions, Final Paper Summary = taskSettings.finalSummaryCount
      summariesPerStage[stage] = {
          paperSummaries: Array(maxSessions).fill(null).map((_, index) => ({
              id: `paper-summary-${stage}-${index + 1}`,
              completed: false,
              file: null
          })),
          finalPaperSummary: Array(taskSettings.finalSummaryCount).fill(null).map((_, index) => ({
              id: `final-paper-summary-${stage}-${index + 1}`,
              completed: false,
              file: null
          }))
      };
  });

  return { examsPerStage, summariesPerStage };
}

// Function to generate period data
export function generatePeriodData(daysInPeriod: number, isHighPerformer: boolean) {
  const dailyData = [];
  for (let i = 0; i < daysInPeriod; i++) {
      const tasks = {
          whatsapp: 0,
          reviewContent: isHighPerformer ? getRandomPercentage(90, 100) : getRandomPercentage(),
          paperSummaries: isHighPerformer ? getRandomPercentage(90, 100) : getRandomPercentage(),
          exams: isHighPerformer ? getRandomPercentage(90, 100) : getRandomPercentage(),
          modelExams: isHighPerformer ? getRandomPercentage(90, 100) : getRandomPercentage(),
          teacherReport: isHighPerformer ? getRandomPercentage(90, 100) : getRandomPercentage()
      };
      const overall = Math.round(
          (tasks.whatsapp + tasks.reviewContent + tasks.paperSummaries + tasks.exams + tasks.modelExams + tasks.teacherReport) / 6
      );
      const isDayOff = Math.random() < 0.2;
      let workingHours = 0;
      let delayMinutes = 0;
      let isAbsent = false;

      if (!isDayOff) {
          workingHours = getRandomWorkingHours();
          const delayResult = calculateDelay(workingHours);
          delayMinutes = delayResult.delayMinutes;
          isAbsent = delayResult.isAbsent;
      }

      dailyData.push({
          tasks,
          overall,
          isDayOff,
          workingHours,
          delayMinutes,
          isAbsent
      });
  }
  return dailyData;
}

// Function to aggregate period data
export function aggregatePeriodData(dailyData: any[]) {
  if (dailyData.length === 0) {
      return {
          tasks: {
              whatsapp: 0,
              reviewContent: 0,
              paperSummaries: 0,
              exams: 0,
              modelExams: 0,
              teacherReport: 0
          },
          overall: 0,
          periodDelayMinutes: 0,
          dailyDelays: [],
          warnings: [],
          warningsCount: 0,
          rating: "Low" as const
      };
  }

  const totalTasks = dailyData.reduce((acc, day) => {
      if (!day.isDayOff) {
          acc.whatsapp += day.tasks.whatsapp;
          acc.reviewContent += day.tasks.reviewContent;
          acc.paperSummaries += day.tasks.paperSummaries;
          acc.exams += day.tasks.exams;
          acc.modelExams += day.tasks.modelExams;
          acc.teacherReport += day.tasks.teacherReport;
      }
      return acc;
  }, {
      whatsapp: 0,
      reviewContent: 0,
      paperSummaries: 0,
      exams: 0,
      modelExams: 0,
      teacherReport: 0
  });

  const workingDays = dailyData.filter(day => !day.isDayOff).length;
  const tasks = {
      whatsapp: workingDays > 0 ? Math.round(totalTasks.whatsapp / workingDays) : 0,
      reviewContent: workingDays > 0 ? Math.round(totalTasks.reviewContent / workingDays) : 0,
      paperSummaries: workingDays > 0 ? Math.round(totalTasks.paperSummaries / workingDays) : 0,
      exams: workingDays > 0 ? Math.round(totalTasks.exams / workingDays) : 0,
      modelExams: workingDays > 0 ? Math.round(totalTasks.modelExams / workingDays) : 0,
      teacherReport: workingDays > 0 ? Math.round(totalTasks.teacherReport / workingDays) : 0
  };

  const overall = Math.round(
      (tasks.whatsapp + tasks.reviewContent + tasks.paperSummaries + tasks.exams + tasks.modelExams + tasks.teacherReport) / 6
  );

  const totalDelayMinutes = dailyData.reduce((sum, day) => sum + (day.isDayOff ? 0 : day.delayMinutes), 0);
  const dailyDelays = dailyData.map(day => day.isDayOff ? 0 : day.delayMinutes);
  const isDayOff = dailyData.every(day => day.isDayOff);
  const warnings = calculateTaskWarnings(tasks, totalDelayMinutes, isDayOff);
  const warningsCount = warnings.length;
  let rating: "Hero" | "Steady" | "Low" = "Low";
  if (overall > 90) rating = "Hero";
  else if (overall >= 50) rating = "Steady";

  return {
      tasks,
      overall,
      periodDelayMinutes: totalDelayMinutes,
      dailyDelays,
      warnings,
      warningsCount,
      rating
  };
}
