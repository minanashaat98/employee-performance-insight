
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAppStore } from '@/lib/store';
import Header from '@/components/Header';
import EmployeeHeader from '@/components/employee/EmployeeHeader';
import EmployeeTabs from '@/components/employee/EmployeeTabs';
import DailyTasks from '@/components/employee/DailyTasks';
import MonthlyTasks from '@/components/employee/MonthlyTasks';
import ExamsTracking from '@/components/employee/ExamsTracking';
import SummariesTracking from '@/components/employee/SummariesTracking';
import ScheduleView from '@/components/employee/ScheduleView';
import { useToast } from "@/components/ui/use-toast";

const EmployeeDetail = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { username } = useParams<{ username: string }>();
  const [activeTab, setActiveTab] = useState(() => {
    // Retrieve the last active tab from localStorage or default to 'daily'
    const savedTab = localStorage.getItem(`employeeTab-${username}`);
    return savedTab || 'daily';
  });
  const [selectedDate, setSelectedDate] = useState('2025-03-21');
  const [isLoading, setIsLoading] = useState(true);
  
  const { employees, isAdmin, currentUser } = useAppStore(state => ({
    employees: state.employees,
    isAdmin: state.isAdmin,
    currentUser: state.currentUser
  }));
  
  const employee = username 
    ? employees.find(emp => emp.username === username.toUpperCase())
    : null;
  
  // Save active tab to localStorage whenever it changes
  useEffect(() => {
    if (username) {
      localStorage.setItem(`employeeTab-${username}`, activeTab);
    }
  }, [activeTab, username]);
  
  // If user is not logged in or employee not found, redirect to login
  useEffect(() => {
    if (!currentUser) {
      navigate('/');
    } else if (!employee) {
      if (isAdmin) {
        navigate('/dashboard');
      } else {
        navigate('/');
      }
    } else {
      // Simulate loading for a better UX
      const timer = setTimeout(() => {
        setIsLoading(false);
        toast({
          title: "Employee Profile",
          description: `${employee?.name}'s profile loaded successfully`,
          duration: 3000,
        });
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [currentUser, isAdmin, employee, navigate, toast]);
  
  if (isLoading || !employee) {
    return (
      <div className="min-h-screen bg-gray-100" dir="ltr">
        <Header title="Employee Portal" />
        <div className="flex justify-center items-center h-[calc(100vh-72px)]">
          <div className="bg-white p-8 rounded-lg shadow-md text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Loading employee data...</p>
          </div>
        </div>
      </div>
    );
  }
  
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    toast({
      title: `${tab.charAt(0).toUpperCase() + tab.slice(1)} View`,
      description: `You've switched to the ${tab} view`,
      duration: 2000,
    });
  };
  
  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedDate(e.target.value);
    toast({
      title: "Date Changed",
      description: `Date updated to ${new Date(e.target.value).toLocaleDateString()}`,
      duration: 2000,
    });
  };
  
  return (
    <div className="min-h-screen bg-gray-100" dir="ltr">
      <Header title="Employee Portal" />
      
      <div className="container mx-auto px-4 py-6">
        <div className="mb-6">
          <div className="flex justify-end mb-4">
            <div className="flex items-center space-x-2 bg-white px-4 py-2 rounded-lg shadow">
              <label className="text-sm font-medium text-gray-700">Date:</label>
              <input 
                type="date" 
                className="rounded border border-gray-300 px-2 py-1 focus:border-blue-500 focus:ring-blue-500" 
                value={selectedDate}
                onChange={handleDateChange}
              />
            </div>
          </div>
          
          <EmployeeHeader employee={employee} />
        </div>
        
        <EmployeeTabs activeTab={activeTab} onTabChange={handleTabChange} />
        
        <div className="bg-white rounded-lg shadow-md p-6 transition-all duration-300">
          {activeTab === 'daily' && (
            <div className="animate-fade-in">
              <DailyTasks employee={employee} selectedDate={selectedDate} />
            </div>
          )}
          
          {activeTab === 'monthly' && (
            <div className="animate-fade-in">
              <MonthlyTasks employee={employee} />
            </div>
          )}
          
          {activeTab === 'exams' && (
            <div className="animate-fade-in">
              <ExamsTracking employee={employee} />
            </div>
          )}
          
          {activeTab === 'summaries' && (
            <div className="animate-fade-in">
              <SummariesTracking employee={employee} />
            </div>
          )}
          
          {activeTab === 'schedule' && (
            <div className="animate-fade-in">
              <ScheduleView employee={employee} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EmployeeDetail;
