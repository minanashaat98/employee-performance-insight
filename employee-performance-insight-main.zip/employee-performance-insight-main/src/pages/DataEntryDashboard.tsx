
import { useState, useEffect } from 'react';
import { useAppStore } from '@/lib/store';
import Header from '@/components/Header';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import DataEntryContent from '@/components/dataentry/DataEntryContent';
import DataEntryNotifications from '@/components/dataentry/DataEntryNotifications';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { FileIcon, Upload, CheckSquare } from 'lucide-react';

const DataEntryDashboard = () => {
  const [activeTab, setActiveTab] = useState('pending');
  const { toast } = useToast();
  const { fileUploads } = useAppStore(state => ({
    fileUploads: state.fileUploads
  }));

  const pendingUploads = fileUploads.filter(upload => !upload.processed);
  const completedUploads = fileUploads.filter(upload => upload.processed);
  
  useEffect(() => {
    toast({
      title: "Data Entry Dashboard",
      description: "Welcome to the data entry dashboard",
      duration: 3000,
    });
  }, [toast]);

  return (
    <div className="min-h-screen bg-gray-100" dir="ltr">
      <Header title="Data Entry Dashboard">
        <div className="flex items-center gap-4">
          <DataEntryNotifications />
        </div>
      </Header>
      
      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-gradient-to-tr from-purple-100 to-blue-50 border-none shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-medium">Pending Files</CardTitle>
              <CardDescription>Files waiting to be processed</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-purple-100 text-purple-600 mr-4">
                  <FileIcon className="h-6 w-6" />
                </div>
                <div>
                  <span className="text-3xl font-bold">{pendingUploads.length}</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-tr from-green-100 to-teal-50 border-none shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-medium">Processed Files</CardTitle>
              <CardDescription>Files that have been processed</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-100 text-green-600 mr-4">
                  <CheckSquare className="h-6 w-6" />
                </div>
                <div>
                  <span className="text-3xl font-bold">{completedUploads.length}</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-tr from-blue-100 to-indigo-50 border-none shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-medium">Total Uploads</CardTitle>
              <CardDescription>All files in the system</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600 mr-4">
                  <Upload className="h-6 w-6" />
                </div>
                <div>
                  <span className="text-3xl font-bold">{fileUploads.length}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Card className="shadow-lg border-none">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl font-bold">Content Management</CardTitle>
              <img 
                src="/lovable-uploads/51421186-40ae-4c70-8b2e-b41c31a43a21.png" 
                alt="Company Logo" 
                className="h-8 w-auto" 
              />
            </div>
            <CardDescription>Manage and process file uploads from employees</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="pending" value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="mb-6 w-full justify-start bg-gray-100 p-1">
                <TabsTrigger 
                  value="pending" 
                  className="flex items-center gap-2 data-[state=active]:bg-white"
                >
                  <FileIcon className="h-4 w-4" />
                  Pending Files
                  {pendingUploads.length > 0 && (
                    <span className="ml-1 rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-medium text-red-600">
                      {pendingUploads.length}
                    </span>
                  )}
                </TabsTrigger>
                <TabsTrigger 
                  value="completed"
                  className="flex items-center gap-2 data-[state=active]:bg-white"
                >
                  <CheckSquare className="h-4 w-4" />
                  Completed Files
                  {completedUploads.length > 0 && (
                    <span className="ml-1 rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-600">
                      {completedUploads.length}
                    </span>
                  )}
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="pending" className="mt-0">
                <DataEntryContent status="pending" />
              </TabsContent>
              
              <TabsContent value="completed" className="mt-0">
                <DataEntryContent status="completed" />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DataEntryDashboard;
