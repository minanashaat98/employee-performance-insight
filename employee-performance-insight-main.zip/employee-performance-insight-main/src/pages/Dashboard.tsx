import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '@/lib/store';
import Header from '@/components/Header';
import Sidebar from '@/components/dashboard/Sidebar';
import DashboardContent from '@/components/dashboard/DashboardContent';
import SettingsContent from '@/components/dashboard/SettingsContent';
import { isFutureDate } from '@/lib/utils';
import { useToast } from "@/components/ui/use-toast";

const Dashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [currentDate, setCurrentDate] = useState('2025-03-21');
  const [filters, setFilters] = useState({
    subject: 'all',
    stage: 'all',
    rating: 'all',
    sort: 'overall-desc'
  });
  const [isLoading, setIsLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());

  const { employees, isAdmin, currentUser } = useAppStore(state => ({
    employees: state.employees,
    isAdmin: state.isAdmin,
    currentUser: state.currentUser
  }));

  // Keep time updated
  useEffect(() => {
    const timerID = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timerID);
  }, []);

  // If user is not logged in or not an admin, redirect to login
  useEffect(() => {
    if (!currentUser || !isAdmin) {
      navigate('/');
    } else {
      // Simulate loading for a better UX
      const timer = setTimeout(() => {
        setIsLoading(false);
        toast({
          title: "Dashboard Loaded",
          description: "Welcome to the Employee Management Dashboard",
          duration: 3000,
        });
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [currentUser, isAdmin, navigate, toast]);

  // Apply filters to employees list
  const filteredEmployees = employees.filter(employee => {
    // Filter by selected subject
    if (filters.subject !== 'all' && !employee.subjects.includes(filters.subject)) {
      return false;
    }
    
    // Filter by selected stage
    if (filters.stage !== 'all' && employee.stage !== filters.stage) {
      return false;
    }
    
    // Filter by selected rating
    if (filters.rating !== 'all' && employee.rating !== filters.rating) {
      return false;
    }
    
    return true;
  }).sort((a, b) => {
    // Sort by selected option
    switch(filters.sort) {
      case 'overall-desc':
        return b.overall - a.overall;
      case 'overall-asc':
        return a.overall - b.overall;
      case 'name-asc':
        return a.name.localeCompare(b.name);
      case 'name-desc':
        return b.name.localeCompare(a.name);
      default:
        return 0;
    }
  }).map(employee => {
    // Zero out data for future dates
    if (isFutureDate(currentDate)) {
      return {
        ...employee,
        tasks: {
          whatsapp: 0,
          reviewContent: 0,
          paperSummaries: 0,
          exams: 0,
          modelExams: 0,
          teacherReport: 0
        },
        overall: 0,
        rating: "Low",
        warnings: [],
        warningsCount: 0
      };
    }
    return employee;
  });

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    // Add a toast notification when changing tabs
    toast({
      title: `${tab === 'dashboard' ? 'Dashboard' : 'Settings'} View`,
      description: `You've switched to the ${tab === 'dashboard' ? 'dashboard overview' : 'system settings'} view.`,
      duration: 2000,
    });
  };

  const handleDateChange = (date: string) => {
    setCurrentDate(date);
  };

  const handleFilterChange = (newFilters: any) => {
    setFilters(newFilters);
    toast({
      title: "Filters Applied",
      description: `Showing ${filteredEmployees.length} employees with the selected filters.`,
      duration: 2000,
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-100">
        <Header title="Employee Management Dashboard" />
        <div className="flex justify-center items-center h-[calc(100vh-72px)]">
          <div className="bg-white p-8 rounded-lg shadow-md text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Loading dashboard data...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Header title="Employee Management Dashboard" />
      
      <div className="flex">
        <Sidebar 
          onTabChange={handleTabChange} 
          activeTab={activeTab} 
          onDateChange={handleDateChange}
          onFilterChange={handleFilterChange}
        />
        
        <div className="flex-1 p-6 overflow-y-auto max-h-[calc(100vh-72px)]">
          {activeTab === 'dashboard' ? (
            <DashboardContent 
              currentDate={currentDate}
              currentTime={currentTime}
              filteredEmployees={filteredEmployees}
            />
          ) : (
            <SettingsContent />
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
