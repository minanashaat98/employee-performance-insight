
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '@/lib/store';
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter 
} from "@/components/ui/dialog";
import { useFirebase } from '@/lib/firebase/FirebaseContext';
import { Eye, EyeOff } from 'lucide-react';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [openResetDialog, setOpenResetDialog] = useState(false);
  const [resetLoading, setResetLoading] = useState(false);
  
  const { login: storeLogin, isAdmin, isDataEntry } = useAppStore(state => ({ 
    login: state.login, 
    isAdmin: state.isAdmin,
    isDataEntry: state.isDataEntry
  }));
  const navigate = useNavigate();
  const { toast } = useToast();
  const { auth } = useFirebase();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate network delay
    setTimeout(() => {
      const success = storeLogin(username, password);
      
      if (success) {
        toast({
          title: "Login Successful",
          description: "Welcome to the Employee Management System!",
          duration: 3000,
        });
        
        // Redirect based on role
        if (isAdmin) {
          navigate('/dashboard');
        } else if (isDataEntry) {
          navigate('/dataentry');
        } else {
          navigate('/employee');
        }
      } else {
        toast({
          title: "Login Failed",
          description: "Invalid username or password. Please try again.",
          variant: "destructive",
          duration: 3000,
        });
      }
      
      setIsLoading(false);
    }, 800);
  };

  const handleResetPassword = async () => {
    if (!resetEmail.trim()) {
      toast({
        title: "Email Required",
        description: "Please enter your email address",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }

    setResetLoading(true);
    
    try {
      await auth.resetPassword(resetEmail);
      toast({
        title: "Password Reset Email Sent",
        description: "Please check your email for instructions to reset your password",
        duration: 5000,
      });
      setOpenResetDialog(false);
      setResetEmail('');
    } catch (error) {
      toast({
        title: "Password Reset Failed",
        description: "There was an error sending the password reset email. Please try again.",
        variant: "destructive",
        duration: 5000,
      });
      console.error("Password reset error:", error);
    } finally {
      setResetLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50" dir="ltr">
      <div className="max-w-md w-full p-6 bg-white rounded-lg shadow-lg">
        <div className="flex justify-center mb-6">
          <img 
            src="/lovable-uploads/51421186-40ae-4c70-8b2e-b41c31a43a21.png" 
            alt="Company Logo" 
            className="h-16 w-auto" 
          />
        </div>
        
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">
          Employee Management System
        </h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1">
              Username
            </Label>
            <Input
              id="username"
              name="username"
              type="text"
              autoComplete="username"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-2"
              placeholder="Enter your username"
            />
          </div>
          
          <div>
            <Label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
              Password
            </Label>
            <div className="relative">
              <Input
                id="password"
                name="password"
                type={showPassword ? "text" : "password"}
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2 pr-10"
                placeholder="Enter your password"
              />
              <button 
                type="button"
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-500"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            <div className="flex justify-end mt-2">
              <button 
                type="button"
                onClick={() => setOpenResetDialog(true)}
                className="text-sm text-blue-600 hover:text-blue-800"
              >
                Forgot password?
              </button>
            </div>
          </div>
          
          <div>
            <Button
              type="submit"
              disabled={isLoading}
              className="w-full flex justify-center items-center py-2 px-4"
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Signing in...
                </>
              ) : (
                "Sign in"
              )}
            </Button>
          </div>
        </form>
        
        <div className="mt-6 p-4 bg-blue-50 rounded-md">
          <h3 className="text-sm font-medium text-blue-800 mb-2">Login Information (For Demo)</h3>
          <div className="space-y-2 text-xs text-blue-700">
            <p><strong>Admin:</strong> Username: ADMIN / Password: admin123</p>
            <p><strong>Data Entry:</strong> Username: DATAENTRY / Password: data123</p>
            <p><strong>Employee:</strong> Username: JOHN001 / Password: password123</p>
          </div>
        </div>
      </div>

      <Dialog open={openResetDialog} onOpenChange={setOpenResetDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Reset password</DialogTitle>
            <DialogDescription>
              Enter your email address and we'll send you a link to reset your password.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="resetEmail" className="text-right">
                Email
              </Label>
              <Input
                id="resetEmail"
                type="email"
                value={resetEmail}
                onChange={(e) => setResetEmail(e.target.value)}
                className="col-span-3"
                placeholder="your-email@example.com"
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              onClick={handleResetPassword} 
              disabled={resetLoading}
            >
              {resetLoading ? "Sending..." : "Send reset link"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Login;
