
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import DataEntryDashboard from "./pages/DataEntryDashboard";
import Employee from "./pages/Employee";
import EmployeeDetail from "./pages/EmployeeDetail";
import { useAppStore } from "./lib/store";
import { FirebaseProvider } from "./lib/firebase/FirebaseContext";

const queryClient = new QueryClient();

const App = () => {
  const { currentUser, isAdmin, isDataEntry } = useAppStore(state => ({
    currentUser: state.currentUser,
    isAdmin: state.isAdmin,
    isDataEntry: state.isDataEntry
  }));

  // Guard routes based on auth state
  const RequireAuth = ({ children }: { children: JSX.Element }) => {
    return currentUser ? children : <Navigate to="/" />;
  };
  
  const RequireAdmin = ({ children }: { children: JSX.Element }) => {
    return currentUser && isAdmin ? children : <Navigate to="/" />;
  };
  
  const RequireDataEntry = ({ children }: { children: JSX.Element }) => {
    return currentUser && isDataEntry ? children : <Navigate to="/" />;
  };

  return (
    <QueryClientProvider client={queryClient}>
      <FirebaseProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Login />} />
              <Route 
                path="/dashboard"
                element={
                  <RequireAdmin>
                    <Dashboard />
                  </RequireAdmin>
                }
              />
              <Route 
                path="/dataentry"
                element={
                  <RequireDataEntry>
                    <DataEntryDashboard />
                  </RequireDataEntry>
                }
              />
              <Route 
                path="/employee" 
                element={
                  <RequireAuth>
                    <Employee />
                  </RequireAuth>
                }
              />
              <Route 
                path="/employee/:username" 
                element={
                  <RequireAuth>
                    <EmployeeDetail />
                  </RequireAuth>
                }
              />
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </FirebaseProvider>
    </QueryClientProvider>
  );
};

export default App;
