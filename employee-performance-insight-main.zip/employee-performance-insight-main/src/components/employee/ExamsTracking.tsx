
import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { useToast } from '@/components/ui/use-toast';

interface ExamsTrackingProps {
  employee: any;
}

const ExamsTracking = ({ employee }: ExamsTrackingProps) => {
  const { updateExamStatus, uploadExamFile } = useAppStore(state => ({
    updateExamStatus: state.updateExamStatus,
    uploadExamFile: state.uploadExamFile
  }));
  const { toast } = useToast();

  const [fileUploads, setFileUploads] = useState<Record<string, File | null>>({});
  const [isUploading, setIsUploading] = useState<Record<string, boolean>>({});

  const handleStatusChange = (
    stage: string, 
    type: 'exams' | 'modelExams', 
    index: number, 
    checked: boolean
  ) => {
    updateExamStatus(employee.id, stage, type, index, checked);
    toast({
      title: `Exam ${checked ? 'Completed' : 'Marked Incomplete'}`,
      description: `${type === 'exams' ? 'Regular' : 'Model'} exam status updated successfully.`,
      duration: 2000,
    });
  };

  const handleFileChange = async (
    stage: string, 
    type: 'exams' | 'modelExams', 
    index: number, 
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    e.preventDefault();
    const file = e.target.files?.[0] || null;
    if (file) {
      const fileId = `${stage}-${type}-${index}`;
      setFileUploads({ ...fileUploads, [fileId]: file });
      
      // Set uploading state
      setIsUploading(prev => ({ ...prev, [fileId]: true }));
      
      try {
        // Create a URL for the file
        const fileURL = URL.createObjectURL(file);
        
        // Update the store with the file URL
        uploadExamFile(employee.id, stage, type, index, fileURL, file.name);
        
        toast({
          title: "File Uploaded",
          description: `${file.name} has been uploaded successfully.`,
          duration: 2000,
        });
      } catch (error) {
        toast({
          title: "Upload Failed",
          description: "There was a problem uploading your file.",
          variant: "destructive",
          duration: 3000,
        });
        console.error("File upload error:", error);
      } finally {
        // Reset uploading state
        setIsUploading(prev => ({ ...prev, [fileId]: false }));
      }
    }
  };

  const handleChangeFile = (
    e: React.MouseEvent,
    stage: string, 
    type: 'exams' | 'modelExams', 
    index: number
  ) => {
    e.preventDefault();
    // Reset the file state to allow re-upload
    const exam = employee.examsPerStage[stage][type][index];
    if (exam.file) {
      URL.revokeObjectURL(exam.file);
      
      // Create a fake event to trigger the upload dialog
      const fileId = `file-${stage}-${type}-${index}`;
      const fileInput = document.getElementById(fileId) as HTMLInputElement;
      if (fileInput) {
        fileInput.value = '';
        fileInput.click();
      }
    }
  };

  return (
    <div className="space-y-8" dir="ltr">
      {Object.keys(employee.examsPerStage).map((stage) => (
        <div key={stage} className="bg-white rounded-lg shadow p-6">
          <h3 className="text-xl font-medium mb-6">{stage} Stage</h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Regular Exams */}
            <div>
              <h4 className="text-lg font-medium mb-4">Exams</h4>
              <div className="space-y-4">
                {employee.examsPerStage[stage].exams.map((exam: any, index: number) => (
                  <div key={exam.id} className="border rounded-md p-4 bg-gray-50">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id={`exam-${stage}-${index}`}
                          checked={exam.completed}
                          onChange={(e) => handleStatusChange(stage, 'exams', index, e.target.checked)}
                          className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                        />
                        <label htmlFor={`exam-${stage}-${index}`} className="ml-2 text-sm font-medium text-gray-700">
                          Exam {index + 1}
                        </label>
                      </div>
                      
                      <div className="flex items-center">
                        {exam.file ? (
                          <div className="flex items-center space-x-2">
                            <a 
                              href={exam.file} 
                              target="_blank" 
                              rel="noreferrer" 
                              className="text-sm text-blue-600 hover:text-blue-800"
                              onClick={(e) => e.stopPropagation()}
                            >
                              View
                            </a>
                            <button
                              onClick={(e) => handleChangeFile(e, stage, 'exams', index)}
                              className="text-xs bg-gray-200 hover:bg-gray-300 text-gray-700 px-2 py-1 rounded"
                            >
                              Change
                            </button>
                            <span className="text-xs text-gray-500 truncate max-w-[100px]">
                              {exam.fileName || 'File'}
                            </span>
                          </div>
                        ) : (
                          <div>
                            {isUploading[`${stage}-exams-${index}`] ? (
                              <div className="flex items-center space-x-2">
                                <span className="animate-spin h-4 w-4 border-2 border-blue-500 border-t-transparent rounded-full"></span>
                                <span className="text-sm text-gray-600">Uploading...</span>
                              </div>
                            ) : (
                              <input
                                id={`file-${stage}-exams-${index}`}
                                type="file"
                                accept=".pdf,.doc,.docx,.jpg,.png"
                                onChange={(e) => handleFileChange(stage, 'exams', index, e)}
                                onClick={(e) => e.stopPropagation()}
                                className="block w-full text-sm text-gray-500
                                  file:mr-4 file:py-1 file:px-2
                                  file:rounded file:border-0
                                  file:text-sm file:font-medium
                                  file:bg-blue-50 file:text-blue-700
                                  hover:file:bg-blue-100"
                              />
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Model Exams */}
            <div>
              <h4 className="text-lg font-medium mb-4">Model Exams</h4>
              <div className="space-y-4">
                {employee.examsPerStage[stage].modelExams.map((exam: any, index: number) => (
                  <div key={exam.id} className="border rounded-md p-4 bg-gray-50">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id={`model-exam-${stage}-${index}`}
                          checked={exam.completed}
                          onChange={(e) => handleStatusChange(stage, 'modelExams', index, e.target.checked)}
                          className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                        />
                        <label htmlFor={`model-exam-${stage}-${index}`} className="ml-2 text-sm font-medium text-gray-700">
                          Model Exam {index + 1}
                        </label>
                      </div>
                      
                      <div className="flex items-center">
                        {exam.file ? (
                          <div className="flex items-center space-x-2">
                            <a 
                              href={exam.file} 
                              target="_blank" 
                              rel="noreferrer" 
                              className="text-sm text-blue-600 hover:text-blue-800"
                              onClick={(e) => e.stopPropagation()}
                            >
                              View
                            </a>
                            <button
                              onClick={(e) => handleChangeFile(e, stage, 'modelExams', index)}
                              className="text-xs bg-gray-200 hover:bg-gray-300 text-gray-700 px-2 py-1 rounded"
                            >
                              Change
                            </button>
                            <span className="text-xs text-gray-500 truncate max-w-[100px]">
                              {exam.fileName || 'File'}
                            </span>
                          </div>
                        ) : (
                          <div>
                            {isUploading[`${stage}-modelExams-${index}`] ? (
                              <div className="flex items-center space-x-2">
                                <span className="animate-spin h-4 w-4 border-2 border-blue-500 border-t-transparent rounded-full"></span>
                                <span className="text-sm text-gray-600">Uploading...</span>
                              </div>
                            ) : (
                              <input
                                id={`file-${stage}-modelExams-${index}`}
                                type="file"
                                accept=".pdf,.doc,.docx,.jpg,.png"
                                onChange={(e) => handleFileChange(stage, 'modelExams', index, e)}
                                onClick={(e) => e.stopPropagation()}
                                className="block w-full text-sm text-gray-500
                                  file:mr-4 file:py-1 file:px-2
                                  file:rounded file:border-0
                                  file:text-sm file:font-medium
                                  file:bg-blue-50 file:text-blue-700
                                  hover:file:bg-blue-100"
                              />
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ExamsTracking;
