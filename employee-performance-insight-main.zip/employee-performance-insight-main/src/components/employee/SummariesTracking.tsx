
import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { useToast } from '@/components/ui/use-toast';

interface SummariesTrackingProps {
  employee: any;
}

const SummariesTracking = ({ employee }: SummariesTrackingProps) => {
  const { updateSummaryStatus, uploadSummaryFile } = useAppStore(state => ({
    updateSummaryStatus: state.updateSummaryStatus,
    uploadSummaryFile: state.uploadSummaryFile
  }));
  const { toast } = useToast();

  const [fileUploads, setFileUploads] = useState<Record<string, File | null>>({});
  const [isUploading, setIsUploading] = useState<Record<string, boolean>>({});

  const handleStatusChange = (
    stage: string, 
    type: 'paperSummaries' | 'finalPaperSummary', 
    index: number, 
    checked: boolean
  ) => {
    updateSummaryStatus(employee.id, stage, type, index, checked);
    toast({
      title: `Summary ${checked ? 'Completed' : 'Marked Incomplete'}`,
      description: `${type === 'paperSummaries' ? 'Paper' : 'Final'} summary status updated successfully.`,
      duration: 2000,
    });
  };

  const handleFileChange = async (
    stage: string, 
    type: 'paperSummaries' | 'finalPaperSummary', 
    index: number, 
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    e.preventDefault();
    const file = e.target.files?.[0] || null;
    if (file) {
      const fileId = `${stage}-${type}-${index}`;
      setFileUploads({ ...fileUploads, [fileId]: file });
      
      // Set uploading state
      setIsUploading(prev => ({ ...prev, [fileId]: true }));
      
      try {
        // Create a URL for the file
        const fileURL = URL.createObjectURL(file);
        
        // Update the store with the file URL
        uploadSummaryFile(employee.id, stage, type, index, fileURL, file.name);
        
        toast({
          title: "File Uploaded",
          description: `${file.name} has been uploaded successfully.`,
          duration: 2000,
        });
      } catch (error) {
        toast({
          title: "Upload Failed",
          description: "There was a problem uploading your file.",
          variant: "destructive",
          duration: 3000,
        });
        console.error("File upload error:", error);
      } finally {
        // Reset uploading state
        setIsUploading(prev => ({ ...prev, [fileId]: false }));
      }
    }
  };

  const handleChangeFile = (
    e: React.MouseEvent,
    stage: string, 
    type: 'paperSummaries' | 'finalPaperSummary', 
    index: number
  ) => {
    e.preventDefault();
    // Reset the file state to allow re-upload
    const summary = employee.summariesPerStage[stage][type][index];
    if (summary.file) {
      URL.revokeObjectURL(summary.file);
      
      // Create a fake event to trigger the upload dialog
      const fileId = `file-${stage}-${type}-${index}`;
      const fileInput = document.getElementById(fileId) as HTMLInputElement;
      if (fileInput) {
        fileInput.value = '';
        fileInput.click();
      }
    }
  };

  return (
    <div className="space-y-8" dir="ltr">
      {Object.keys(employee.summariesPerStage).map((stage) => (
        <div key={stage} className="bg-white rounded-lg shadow p-6">
          <h3 className="text-xl font-medium mb-6">{stage} Stage</h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Paper Summaries */}
            <div>
              <h4 className="text-lg font-medium mb-4">Paper Summaries</h4>
              <div className="space-y-4">
                {employee.summariesPerStage[stage].paperSummaries.map((summary: any, index: number) => (
                  <div key={summary.id} className="border rounded-md p-4 bg-gray-50">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id={`summary-${stage}-${index}`}
                          checked={summary.completed}
                          onChange={(e) => handleStatusChange(stage, 'paperSummaries', index, e.target.checked)}
                          className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                        />
                        <label htmlFor={`summary-${stage}-${index}`} className="ml-2 text-sm font-medium text-gray-700">
                          Paper Summary {index + 1}
                        </label>
                      </div>
                      
                      <div className="flex items-center">
                        {summary.file ? (
                          <div className="flex items-center space-x-2">
                            <a 
                              href={summary.file} 
                              target="_blank" 
                              rel="noreferrer" 
                              className="text-sm text-blue-600 hover:text-blue-800"
                              onClick={(e) => e.stopPropagation()}
                            >
                              View
                            </a>
                            <button
                              onClick={(e) => handleChangeFile(e, stage, 'paperSummaries', index)}
                              className="text-xs bg-gray-200 hover:bg-gray-300 text-gray-700 px-2 py-1 rounded"
                            >
                              Change
                            </button>
                            <span className="text-xs text-gray-500 truncate max-w-[100px]">
                              {summary.fileName || 'File'}
                            </span>
                          </div>
                        ) : (
                          <div>
                            {isUploading[`${stage}-paperSummaries-${index}`] ? (
                              <div className="flex items-center space-x-2">
                                <span className="animate-spin h-4 w-4 border-2 border-blue-500 border-t-transparent rounded-full"></span>
                                <span className="text-sm text-gray-600">Uploading...</span>
                              </div>
                            ) : (
                              <input
                                id={`file-${stage}-paperSummaries-${index}`}
                                type="file"
                                accept=".pdf,.doc,.docx,.jpg,.png"
                                onChange={(e) => handleFileChange(stage, 'paperSummaries', index, e)}
                                onClick={(e) => e.stopPropagation()}
                                className="block w-full text-sm text-gray-500
                                  file:mr-4 file:py-1 file:px-2
                                  file:rounded file:border-0
                                  file:text-sm file:font-medium
                                  file:bg-blue-50 file:text-blue-700
                                  hover:file:bg-blue-100"
                              />
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Final Paper Summaries */}
            <div>
              <h4 className="text-lg font-medium mb-4">Final Paper Summary</h4>
              <div className="space-y-4">
                {employee.summariesPerStage[stage].finalPaperSummary.map((summary: any, index: number) => (
                  <div key={summary.id} className="border rounded-md p-4 bg-gray-50">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id={`final-summary-${stage}-${index}`}
                          checked={summary.completed}
                          onChange={(e) => handleStatusChange(stage, 'finalPaperSummary', index, e.target.checked)}
                          className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                        />
                        <label htmlFor={`final-summary-${stage}-${index}`} className="ml-2 text-sm font-medium text-gray-700">
                          Final Paper Summary {index + 1}
                        </label>
                      </div>
                      
                      <div className="flex items-center">
                        {summary.file ? (
                          <div className="flex items-center space-x-2">
                            <a 
                              href={summary.file} 
                              target="_blank" 
                              rel="noreferrer" 
                              className="text-sm text-blue-600 hover:text-blue-800"
                              onClick={(e) => e.stopPropagation()}
                            >
                              View
                            </a>
                            <button
                              onClick={(e) => handleChangeFile(e, stage, 'finalPaperSummary', index)}
                              className="text-xs bg-gray-200 hover:bg-gray-300 text-gray-700 px-2 py-1 rounded"
                            >
                              Change
                            </button>
                            <span className="text-xs text-gray-500 truncate max-w-[100px]">
                              {summary.fileName || 'File'}
                            </span>
                          </div>
                        ) : (
                          <div>
                            {isUploading[`${stage}-finalPaperSummary-${index}`] ? (
                              <div className="flex items-center space-x-2">
                                <span className="animate-spin h-4 w-4 border-2 border-blue-500 border-t-transparent rounded-full"></span>
                                <span className="text-sm text-gray-600">Uploading...</span>
                              </div>
                            ) : (
                              <input
                                id={`file-${stage}-finalPaperSummary-${index}`}
                                type="file"
                                accept=".pdf,.doc,.docx,.jpg,.png"
                                onChange={(e) => handleFileChange(stage, 'finalPaperSummary', index, e)}
                                onClick={(e) => e.stopPropagation()}
                                className="block w-full text-sm text-gray-500
                                  file:mr-4 file:py-1 file:px-2
                                  file:rounded file:border-0
                                  file:text-sm file:font-medium
                                  file:bg-blue-50 file:text-blue-700
                                  hover:file:bg-blue-100"
                              />
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SummariesTracking;
