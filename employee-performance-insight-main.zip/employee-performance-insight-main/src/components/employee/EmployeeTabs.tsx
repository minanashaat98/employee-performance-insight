
import { motion } from 'framer-motion';
import { Calendar, Clock, FileText, ClipboardList, CalendarCheck } from 'lucide-react';

interface EmployeeTabsProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const EmployeeTabs = ({ activeTab, onTabChange }: EmployeeTabsProps) => {
  const tabs = [
    { id: 'daily', name: 'Daily Tasks', icon: Clock },
    { id: 'monthly', name: 'Monthly Tasks', icon: Calendar },
    { id: 'exams', name: 'Exams Tracking', icon: FileText },
    { id: 'summaries', name: 'Summaries Tracking', icon: ClipboardList },
    { id: 'schedule', name: 'Schedule', icon: CalendarCheck },
  ];

  return (
    <div className="bg-white rounded-lg shadow-md mb-6 overflow-x-auto">
      <div className="flex w-full min-w-max">
        {tabs.map((tab) => (
          <motion.button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            whileHover={{ backgroundColor: 'rgba(237, 242, 247, 0.7)' }}
            whileTap={{ scale: 0.98 }}
            className={`
              flex items-center justify-center py-4 px-6 font-medium text-sm focus:outline-none relative flex-1
              ${activeTab === tab.id
                ? 'text-blue-600'
                : 'text-gray-500 hover:text-gray-800'
              }
            `}
          >
            <div className="flex items-center gap-2">
              <tab.icon size={18} />
              <span>{tab.name}</span>
            </div>
            
            {activeTab === tab.id && (
              <motion.div 
                className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600"
                layoutId="activeTab"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              />
            )}
          </motion.button>
        ))}
      </div>
    </div>
  );
};

export default EmployeeTabs;
