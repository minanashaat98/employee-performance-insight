
import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { isFutureDate } from '@/lib/utils';
import WhatsappModal from './WhatsappModal';
import EditRequestModal from './EditRequestModal';

interface DailyTasksProps {
  employee: any;
  selectedDate: string;
}

const DailyTasks = ({ employee, selectedDate }: DailyTasksProps) => {
  const [isWhatsappModalOpen, setIsWhatsappModalOpen] = useState(false);
  const [isEditRequestModalOpen, setIsEditRequestModalOpen] = useState(false);

  const whatsappData = employee.whatsappDailyData.find((data: any) => data.date === selectedDate);
  const isFuture = isFutureDate(selectedDate);

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium mb-4">Status</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Working Hours:</span>
              <span className="font-medium">{isFuture ? 0 : employee.workingHours.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Delayed:</span>
              <span className={`font-medium ${isFuture ? 'text-gray-500' : employee.delayMinutes > 0 ? 'text-red-600' : 'text-green-600'}`}>
                {isFuture ? 'N/A' : (employee.isDayOff ? "Day Off" : (employee.delayMinutes > 0 ? "Yes" : "No"))}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Delay Minutes:</span>
              <span className={`font-medium ${isFuture ? 'text-gray-500' : employee.delayMinutes > 0 ? 'text-red-600' : 'text-gray-900'}`}>
                {isFuture ? 0 : employee.delayMinutes}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Status:</span>
              <span className={`font-medium ${
                isFuture ? 'text-gray-500' : 
                employee.isDayOff ? 'text-blue-600' : 
                employee.isAbsent ? 'text-red-600' : 'text-green-600'
              }`}>
                {isFuture ? 'Future Date' : (employee.isDayOff ? "Day Off" : (employee.isAbsent ? "Absent" : "Present"))}
              </span>
            </div>
          </div>
        </div>
        
        <div className="md:col-span-2 bg-white rounded-lg shadow p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium">WhatsApp Chats</h3>
            {!isFuture && (
              <button
                onClick={() => setIsWhatsappModalOpen(true)}
                className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700"
                disabled={whatsappData?.isLocked}
              >
                {whatsappData ? 'Update Data' : 'Enter Data'}
              </button>
            )}
          </div>
          
          {whatsappData?.isLocked && !isFuture && (
            <div className="flex justify-between items-center mb-4">
              <p className="text-sm text-amber-600">This data is locked for editing.</p>
              <button
                onClick={() => setIsEditRequestModalOpen(true)}
                className="px-3 py-1 bg-amber-500 text-white rounded text-sm hover:bg-amber-600"
              >
                Request Edit
              </button>
            </div>
          )}
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gray-50 p-4 rounded">
              <p className="text-sm text-gray-500">Rating</p>
              <p className="text-xl font-semibold">{whatsappData?.rating || 0}%</p>
              <p className="text-sm text-red-500 mt-2">
                {(whatsappData?.rating || 0) < 50 ? '⚠️ Warning: Low Rating' : ''}
              </p>
            </div>
            <div className="bg-gray-50 p-4 rounded">
              <p className="text-sm text-gray-500">Login Chats</p>
              <p className="text-xl font-semibold">{whatsappData?.loginChats || 0}</p>
            </div>
            <div className="bg-gray-50 p-4 rounded">
              <p className="text-sm text-gray-500">Total Chats</p>
              <p className="text-xl font-semibold">{whatsappData?.totalChats || 0}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Task</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Count</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Percentage</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Warning</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            <tr>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">WhatsApp Chats</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{whatsappData?.totalChats || 0}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{whatsappData?.rating || 0}%</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-red-500">
                {(whatsappData?.rating || 0) < 50 ? '⚠️' : '-'}
              </td>
            </tr>
            <tr>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Paper Summaries</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{isFuture ? 0 : employee.dailyTasks.summariesWritten}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{isFuture ? 0 : employee.dailyTasks.percentages.paperSummaries}%</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-red-500">
                {!isFuture && employee.dailyTasks.percentages.paperSummaries < 50 ? '⚠️' : '-'}
              </td>
            </tr>
            <tr>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Content Reviewed</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{isFuture ? 0 : employee.dailyTasks.contentReviewed}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{isFuture ? 0 : employee.dailyTasks.percentages.reviewContent}%</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-red-500">
                {!isFuture && employee.dailyTasks.percentages.reviewContent < 50 ? '⚠️' : '-'}
              </td>
            </tr>
            <tr>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Exams Recorded</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{isFuture ? 0 : employee.dailyTasks.examsRecorded}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{isFuture ? 0 : employee.dailyTasks.percentages.exams}%</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-red-500">
                {!isFuture && employee.dailyTasks.percentages.exams < 50 ? '⚠️' : '-'}
              </td>
            </tr>
            <tr>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Model Exams</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{isFuture ? 0 : employee.dailyTasks.modelExamsRecorded}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{isFuture ? 0 : employee.dailyTasks.percentages.modelExams}%</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-red-500">
                {!isFuture && employee.dailyTasks.percentages.modelExams < 50 ? '⚠️' : '-'}
              </td>
            </tr>
            <tr>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Teacher Reports</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{isFuture ? 0 : employee.dailyTasks.teacherReports}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{isFuture ? 0 : employee.dailyTasks.percentages.teacherReport}%</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-red-500">
                {!isFuture && employee.dailyTasks.percentages.teacherReport < 50 ? '⚠️' : '-'}
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <WhatsappModal
        isOpen={isWhatsappModalOpen}
        onClose={() => setIsWhatsappModalOpen(false)}
        employeeId={employee.id}
        date={selectedDate}
        currentWhatsappData={whatsappData}
      />

      <EditRequestModal
        isOpen={isEditRequestModalOpen}
        onClose={() => setIsEditRequestModalOpen(false)}
        employeeName={employee.name}
        date={selectedDate}
      />
    </div>
  );
};

export default DailyTasks;
