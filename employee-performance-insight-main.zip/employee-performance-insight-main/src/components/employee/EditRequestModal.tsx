
import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { X } from 'lucide-react';
import { toast } from "@/hooks/use-toast";

interface EditRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  employeeName: string;
  date: string;
}

const EditRequestModal = ({ 
  isOpen, 
  onClose, 
  employeeName, 
  date 
}: EditRequestModalProps) => {
  const [reason, setReason] = useState('');
  const [file, setFile] = useState<File | null>(null);
  
  const { addEditRequest } = useAppStore(state => ({
    addEditRequest: state.addEditRequest
  }));

  if (!isOpen) return null;

  const handleSubmit = () => {
    if (!reason.trim()) {
      toast({
        title: "Error",
        description: "Please provide a reason for your edit request",
        variant: "destructive"
      });
      return;
    }

    let attachmentURL = null;
    if (file) {
      attachmentURL = URL.createObjectURL(file);
    }

    addEditRequest({
      employeeName,
      date,
      reason,
      attachment: attachmentURL
    });
    
    toast({
      title: "Success",
      description: "Edit request submitted successfully"
    });
    
    setReason('');
    setFile(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium">Request Edit Permission</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Reason for Edit Request
            </label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={4}
              className="w-full p-2 border border-gray-300 rounded"
              placeholder="Please explain why you need to edit this data..."
            ></textarea>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Attachment (Optional)
            </label>
            <input
              type="file"
              onChange={(e) => setFile(e.target.files?.[0] || null)}
              className="w-full p-2 border border-gray-300 rounded"
              accept=".pdf,.doc,.docx,.jpg,.png"
            />
            <p className="text-xs text-gray-500 mt-1">
              You can upload documents or screenshots to support your request.
            </p>
          </div>
        </div>
        
        <div className="mt-6 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-100 text-gray-800 rounded hover:bg-gray-200"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Submit Request
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditRequestModal;
