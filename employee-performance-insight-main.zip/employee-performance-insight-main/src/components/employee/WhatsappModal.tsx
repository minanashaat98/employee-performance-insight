
import { useState, useEffect } from 'react';
import { useAppStore } from '@/lib/store';
import { X } from 'lucide-react';
import { calculateWhatsappRating } from '@/lib/utils';
import { toast } from "@/hooks/use-toast";

interface WhatsappModalProps {
  isOpen: boolean;
  onClose: () => void;
  employeeId: string;
  date: string;
  currentWhatsappData: any;
}

const WhatsappModal = ({ 
  isOpen, 
  onClose, 
  employeeId, 
  date,
  currentWhatsappData
}: WhatsappModalProps) => {
  const [loginChats, setLoginChats] = useState(0);
  const [logoutChats, setLogoutChats] = useState(0);
  const [totalChats, setTotalChats] = useState(0);
  const [calculatedRating, setCalculatedRating] = useState(0);
  
  const { updateWhatsappData } = useAppStore(state => ({
    updateWhatsappData: state.updateWhatsappData
  }));
  
  useEffect(() => {
    if (currentWhatsappData) {
      setLoginChats(currentWhatsappData.loginChats || 0);
      setLogoutChats(currentWhatsappData.logoutChats || 0);
      setTotalChats(currentWhatsappData.totalChats || 0);
      setCalculatedRating(currentWhatsappData.rating || 0);
    } else {
      setLoginChats(0);
      setLogoutChats(0);
      setTotalChats(0);
      setCalculatedRating(0);
    }
  }, [currentWhatsappData]);
  
  // Recalculate rating when inputs change
  useEffect(() => {
    const rating = calculateWhatsappRating(loginChats, logoutChats, totalChats);
    setCalculatedRating(rating);
  }, [loginChats, logoutChats, totalChats]);

  if (!isOpen) return null;

  const handleSubmit = () => {
    if (totalChats < loginChats || totalChats < logoutChats) {
      toast({
        title: "Error",
        description: "Total chats must be greater than or equal to login and logout chats",
        variant: "destructive"
      });
      return;
    }

    updateWhatsappData(
      employeeId,
      date,
      loginChats,
      logoutChats,
      totalChats,
      calculatedRating
    );
    
    toast({
      title: "Success",
      description: "WhatsApp data saved successfully"
    });
    
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium">WhatsApp Data Entry</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Login Chats
            </label>
            <input
              type="number"
              value={loginChats}
              onChange={(e) => setLoginChats(Math.max(0, parseInt(e.target.value) || 0))}
              className="w-full p-2 border border-gray-300 rounded"
              min="0"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Logout Chats
            </label>
            <input
              type="number"
              value={logoutChats}
              onChange={(e) => setLogoutChats(Math.max(0, parseInt(e.target.value) || 0))}
              className="w-full p-2 border border-gray-300 rounded"
              min="0"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Total Chats
            </label>
            <input
              type="number"
              value={totalChats}
              onChange={(e) => setTotalChats(Math.max(0, parseInt(e.target.value) || 0))}
              className="w-full p-2 border border-gray-300 rounded"
              min="0"
            />
          </div>
          
          <div className="bg-gray-50 p-4 rounded">
            <h4 className="text-sm font-medium text-gray-700 mb-2">Calculated Rating:</h4>
            <p className="text-2xl font-bold text-center">{calculatedRating}%</p>
          </div>
        </div>
        
        <div className="mt-6 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-100 text-gray-800 rounded hover:bg-gray-200"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

export default WhatsappModal;
