
interface MonthlyTasksProps {
  employee: any;
}

const MonthlyTasks = ({ employee }: MonthlyTasksProps) => {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium mb-4">Monthly Summary</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">WhatsApp Chats:</span>
              <span className="font-medium">{employee.monthlyTasks.whatsappChats}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Summaries Written:</span>
              <span className="font-medium">{employee.monthlyTasks.summariesWritten}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Content Reviewed:</span>
              <span className="font-medium">{employee.monthlyTasks.contentReviewed}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Exams Recorded:</span>
              <span className="font-medium">{employee.monthlyTasks.examsRecorded}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Model Exams:</span>
              <span className="font-medium">{employee.monthlyTasks.modelExamsRecorded}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Teacher Reports:</span>
              <span className="font-medium">{employee.monthlyTasks.teacherReports}</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium mb-4">Performance</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Overall Rating:</span>
              <span className="font-bold text-lg">{employee.overall}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Performance Level:</span>
              <span className={`font-medium ${
                employee.rating === 'Hero' ? 'text-green-600' : 
                employee.rating === 'Steady' ? 'text-blue-600' : 
                'text-red-600'
              }`}>
                {employee.rating}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Warnings:</span>
              <span className="font-medium text-red-600">
                {employee.warningsCount > 0 ? employee.warningsCount : '0'}
              </span>
            </div>
            {employee.warnings.length > 0 && (
              <div className="mt-2">
                <span className="text-sm text-gray-600">Warning Areas:</span>
                <ul className="list-disc pl-5 mt-1 text-sm text-red-600">
                  {employee.warnings.map((warning: string, index: number) => (
                    <li key={index}>{warning}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium mb-4">Attendance & Delays</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Total Delay:</span>
              <span className={`font-medium ${employee.periodDelayMinutes > 0 ? 'text-red-600' : 'text-green-600'}`}>
                {employee.periodDelayMinutes} minutes
              </span>
            </div>
            <div className="h-32 overflow-y-auto mt-2">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Day</th>
                    <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Delay</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {employee.dailyDelays.map((delay: number, index: number) => (
                    <tr key={index}>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-900">
                        Day {index + 1}
                      </td>
                      <td className={`px-3 py-2 whitespace-nowrap text-sm ${delay > 0 ? 'text-red-600 font-medium' : 'text-gray-500'}`}>
                        {delay} min
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-medium mb-4">Monthly Performance Summary</h3>
        
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
          <div className="p-4 bg-gray-50 rounded text-center">
            <p className="text-gray-500 text-sm mb-1">WhatsApp</p>
            <p className="text-xl font-bold">{employee.tasks.whatsapp}%</p>
          </div>
          
          <div className="p-4 bg-gray-50 rounded text-center">
            <p className="text-gray-500 text-sm mb-1">Review Content</p>
            <p className="text-xl font-bold">{employee.tasks.reviewContent}%</p>
          </div>
          
          <div className="p-4 bg-gray-50 rounded text-center">
            <p className="text-gray-500 text-sm mb-1">Paper Summaries</p>
            <p className="text-xl font-bold">{employee.tasks.paperSummaries}%</p>
          </div>
          
          <div className="p-4 bg-gray-50 rounded text-center">
            <p className="text-gray-500 text-sm mb-1">Exams</p>
            <p className="text-xl font-bold">{employee.tasks.exams}%</p>
          </div>
          
          <div className="p-4 bg-gray-50 rounded text-center">
            <p className="text-gray-500 text-sm mb-1">Model Exams</p>
            <p className="text-xl font-bold">{employee.tasks.modelExams}%</p>
          </div>
          
          <div className="p-4 bg-gray-50 rounded text-center">
            <p className="text-gray-500 text-sm mb-1">Teacher Report</p>
            <p className="text-xl font-bold">{employee.tasks.teacherReport}%</p>
          </div>
        </div>
        
        <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-100">
          <div className="flex justify-between items-center">
            <div>
              <h4 className="font-medium">Final Summary</h4>
              <p className="text-sm text-gray-600 mt-1">
                Monthly performance based on all metrics
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">Overall Rating</p>
              <p className={`text-2xl font-bold ${
                employee.rating === 'Hero' ? 'text-green-600' : 
                employee.rating === 'Steady' ? 'text-blue-600' : 
                'text-red-600'
              }`}>
                {employee.overall}% ({employee.rating})
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MonthlyTasks;
