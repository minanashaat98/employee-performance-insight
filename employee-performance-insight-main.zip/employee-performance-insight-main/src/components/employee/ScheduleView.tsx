
import { useAppStore } from '@/lib/store';

interface ScheduleViewProps {
  employee: any;
}

const ScheduleView = ({ employee }: ScheduleViewProps) => {
  const { subjectSchedules } = useAppStore(state => ({
    subjectSchedules: state.subjectSchedules
  }));

  // Filter schedules for employee's subjects
  const employeeSchedules = subjectSchedules.filter(
    schedule => employee.subjects.includes(schedule.subject)
  );

  return (
    <div className="space-y-8">
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b">
          <h3 className="text-lg font-medium">Subject Schedule</h3>
          <p className="mt-1 text-sm text-gray-600">
            Schedule for your assigned subjects
          </p>
        </div>
        
        {employeeSchedules.length === 0 ? (
          <div className="p-6 text-center text-gray-500">
            No schedules have been assigned for your subjects yet.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr className="bg-gray-50">
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sessions</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dates</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {employeeSchedules.map((schedule) => (
                  <tr key={schedule.subject}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{schedule.subject}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.sessions}</td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      <div className="flex flex-wrap gap-2">
                        {schedule.dates.map((date, index) => (
                          <span 
                            key={index}
                            className="px-2 py-1 bg-blue-50 text-blue-700 rounded text-xs"
                          >
                            {new Date(date).toLocaleDateString()}
                          </span>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-medium mb-4">Calendar View</h3>
        {/* Placeholder for calendar view - could be implemented with a calendar library */}
        <div className="border-2 border-dashed border-gray-200 rounded-lg h-80 flex items-center justify-center">
          <p className="text-gray-500">Calendar view will be implemented in future versions</p>
        </div>
      </div>
    </div>
  );
};

export default ScheduleView;
