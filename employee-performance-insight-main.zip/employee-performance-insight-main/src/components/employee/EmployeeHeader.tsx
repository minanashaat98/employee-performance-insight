
import { useAppStore } from '@/lib/store';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Award, Users } from 'lucide-react';
import { motion } from 'framer-motion';

interface EmployeeHeaderProps {
  employee: any;
}

const EmployeeHeader = ({ employee }: EmployeeHeaderProps) => {
  const { isAdmin, employees } = useAppStore(state => ({
    isAdmin: state.isAdmin,
    employees: state.employees
  }));
  
  const navigate = useNavigate();
  
  const handleBackToDashboard = () => {
    navigate('/dashboard');
  };

  // Calculate employee ranking
  const sortedEmployees = [...employees].sort((a, b) => b.overall - a.overall);
  const employeeRank = sortedEmployees.findIndex(emp => emp.id === employee.id) + 1;
  const totalEmployees = employees.length;
  
  // Calculate ranking within stage
  const sameStageEmployees = employees.filter(emp => emp.stage === employee.stage);
  const sortedStageEmployees = [...sameStageEmployees].sort((a, b) => b.overall - a.overall);
  const stageRank = sortedStageEmployees.findIndex(emp => emp.id === employee.id) + 1;
  const totalStageEmployees = sameStageEmployees.length;

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-4">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">{employee.name}</h1>
          {isAdmin && (
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleBackToDashboard}
              className="flex items-center gap-2 text-white hover:bg-white/20 rounded-md px-3 py-1 transition-colors"
            >
              <ArrowLeft size={16} />
              <span>Back to Dashboard</span>
            </motion.button>
          )}
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
          <div>
            <div className="flex flex-wrap gap-2 mb-2">
              {employee.subjects.map((subject: string) => (
                <span 
                  key={subject}
                  className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded"
                >
                  {subject}
                </span>
              ))}
            </div>
            <p className="text-gray-600">
              <span className="font-medium">Stage:</span> {employee.stage}
            </p>
          </div>
          
          <div className="md:flex items-center gap-4">
            <div className="bg-yellow-50 border border-yellow-100 px-4 py-2 rounded-lg flex items-center gap-2 mb-2 md:mb-0">
              <Award className="h-5 w-5 text-yellow-500" />
              <div>
                <p className="font-medium text-sm text-yellow-700">Overall Rank</p>
                <p className="text-lg font-bold text-yellow-600">#{employeeRank} <span className="text-xs text-gray-500">of {totalEmployees}</span></p>
              </div>
            </div>
            
            <div className="bg-blue-50 border border-blue-100 px-4 py-2 rounded-lg flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-500" />
              <div>
                <p className="font-medium text-sm text-blue-700">Stage Rank</p>
                <p className="text-lg font-bold text-blue-600">#{stageRank} <span className="text-xs text-gray-500">of {totalStageEmployees}</span></p>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-100 px-4 py-3 rounded-lg">
            <div className="flex items-center justify-between gap-4">
              <span className="text-gray-800 font-medium">Overall Rating:</span>
              <div className="flex items-center gap-2">
                <div className="w-24 bg-gray-200 rounded-full h-2.5">
                  <div 
                    className={`h-2.5 rounded-full ${
                      employee.rating === 'Hero' ? 'bg-green-600' : 
                      employee.rating === 'Steady' ? 'bg-blue-600' : 
                      'bg-red-600'
                    }`}
                    style={{ width: `${employee.overall}%` }}
                  ></div>
                </div>
                <span className={`font-bold ${
                  employee.rating === 'Hero' ? 'text-green-600' : 
                  employee.rating === 'Steady' ? 'text-blue-600' : 
                  'text-red-600'
                }`}>
                  {employee.overall}% ({employee.rating})
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeeHeader;
