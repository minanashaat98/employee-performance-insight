
import { useNavigate } from 'react-router-dom';

interface EmployeeTableProps {
  employees: any[];
}

const EmployeeTable = ({ employees }: EmployeeTableProps) => {
  const navigate = useNavigate();

  const handleEmployeeClick = (username: string) => {
    navigate(`/employee/${username}`);
  };

  const getRatingClass = (rating: string) => {
    switch(rating) {
      case 'Hero': return 'text-green-600 font-bold';
      case 'Steady': return 'text-blue-600 font-bold';
      case 'Low': return 'text-red-600 font-bold';
      default: return '';
    }
  };

  return (
    <div className="overflow-x-auto bg-white rounded-lg shadow">
      <table className="min-w-full divide-y divide-gray-200">
        <thead>
          <tr className="bg-blue-600 text-white">
            <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Name</th>
            <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Subjects</th>
            <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">WhatsApp</th>
            <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Review Content</th>
            <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Paper Summaries</th>
            <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Exams</th>
            <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Model Exams</th>
            <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Teacher Report</th>
            <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Overall</th>
            <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Rating</th>
            <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Warnings</th>
            <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Count</th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {employees.length > 0 ? (
            employees.map((employee) => (
              <tr 
                key={employee.id} 
                className="hover:bg-gray-50 cursor-pointer"
                onClick={() => handleEmployeeClick(employee.username)}
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-blue-600">{employee.name}</div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm text-gray-900">{employee.subjects.join(", ")}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{employee.tasks.whatsapp}%</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{employee.tasks.reviewContent}%</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{employee.tasks.paperSummaries}%</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{employee.tasks.exams}%</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{employee.tasks.modelExams}%</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{employee.tasks.teacherReport}%</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium">{employee.overall}%</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className={`text-sm ${getRatingClass(employee.rating)}`}>
                    {employee.rating}
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm text-red-600">
                    {employee.warnings.length > 0 ? employee.warnings.join(", ") : "-"}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {employee.warningsCount > 0 ? (
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                      {employee.warningsCount}
                    </span>
                  ) : (
                    <span className="text-sm">0</span>
                  )}
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={12} className="px-6 py-4 text-center text-gray-500">
                No employees found matching the filters
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default EmployeeTable;
