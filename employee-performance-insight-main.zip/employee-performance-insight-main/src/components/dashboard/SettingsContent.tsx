
import { useState } from 'react';
import { useToast } from '@/components/ui/use-toast';
import SettingsTabs from '@/components/settings/SettingsTabs';

const SettingsContent = () => {
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();
  
  const handleSave = async (settingType: string) => {
    setIsSaving(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));
    
    setIsSaving(false);
    
    toast({
      title: "Settings Saved",
      description: `${settingType.charAt(0).toUpperCase() + settingType.slice(1)} settings saved successfully.`,
      duration: 3000,
    });
    
    return Promise.resolve();
  };
  
  return (
    <div dir="ltr">
      <h2 className="text-2xl font-bold mb-6">System Settings</h2>
      <SettingsTabs isSaving={isSaving} onSave={handleSave} />
    </div>
  );
};

export default SettingsContent;
