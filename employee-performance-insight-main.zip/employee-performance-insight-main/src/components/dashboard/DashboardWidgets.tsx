
import { useMemo } from 'react';

interface DashboardWidgetsProps {
  employees: any[];
}

const DashboardWidgets = ({ employees }: DashboardWidgetsProps) => {
  const heroesCount = useMemo(() => {
    return employees.filter(emp => emp.rating === "Hero").length;
  }, [employees]);

  const warningsCount = useMemo(() => {
    return employees.reduce((sum, emp) => sum + emp.warningsCount, 0);
  }, [employees]);

  const teamAverage = useMemo(() => {
    if (employees.length === 0) return 0;
    
    const totalOverall = employees.reduce((sum, emp) => sum + emp.overall, 0);
    return Math.round(totalOverall / employees.length);
  }, [employees]);

  const topPerformers = useMemo(() => {
    return [...employees]
      .sort((a, b) => b.overall - a.overall)
      .slice(0, 5);
  }, [employees]);
  
  const getPerformerIcon = (index: number) => {
    switch(index) {
      case 0: return "🥇";
      case 1: return "🥈";
      case 2: return "🥉";
      case 3: return "🏅";
      default: return "🌟";
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <div className="bg-white rounded-lg shadow p-6 text-center">
        <h3 className="text-lg font-medium text-gray-700 mb-2">Team Average</h3>
        <p className="text-3xl font-bold">{teamAverage}%</p>
      </div>
      
      <div className="bg-white rounded-lg shadow p-6 text-center">
        <h3 className="text-lg font-medium text-gray-700 mb-2">Heroes</h3>
        <p className="text-3xl font-bold text-green-600">{heroesCount}</p>
      </div>
      
      <div className="bg-white rounded-lg shadow p-6 text-center">
        <h3 className="text-lg font-medium text-gray-700 mb-2">Warnings</h3>
        <p className="text-3xl font-bold text-red-600">{warningsCount}</p>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-medium text-gray-700 mb-4 text-center">Top Performers</h3>
        <div className="space-y-3">
          {topPerformers.map((performer, index) => (
            <div key={performer.id} className="flex items-center justify-between">
              <div className="flex items-center">
                <span className={`h-6 w-6 rounded-full flex items-center justify-center mr-3 ${
                  index === 0 ? 'bg-yellow-400' : 
                  index === 1 ? 'bg-gray-300' : 
                  index === 2 ? 'bg-yellow-700' : 
                  'bg-blue-500'
                } text-white text-xs font-bold`}>
                  {index + 1}
                </span>
                <span className="text-gray-800">{performer.name}</span>
              </div>
              <div className="flex items-center">
                <span className="text-gray-800 font-medium mr-2">{performer.overall}%</span>
                <span>{getPerformerIcon(index)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DashboardWidgets;
