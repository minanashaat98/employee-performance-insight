
import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { Calendar, Settings } from 'lucide-react';

interface SidebarProps {
  onDateChange: (date: string) => void;
  onFilterChange: (filters: any) => void;
  onTabChange: (tab: string) => void;
  activeTab: string;
}

const Sidebar = ({ onDateChange, onFilterChange, onTabChange, activeTab }: SidebarProps) => {
  const [subjectFilter, setSubjectFilter] = useState('all');
  const [stageFilter, setStageFilter] = useState('all');
  const [ratingFilter, setRatingFilter] = useState('all');
  const [sortFilter, setSortFilter] = useState('overall-desc');

  const { subjects, stages } = useAppStore(state => ({
    subjects: state.subjects,
    stages: state.stages
  }));

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onDateChange(e.target.value);
  };

  const handleFilterChange = () => {
    onFilterChange({
      subject: subjectFilter,
      stage: stageFilter,
      rating: ratingFilter,
      sort: sortFilter
    });
  };

  return (
    <div className="w-64 bg-white p-5 shadow-md flex flex-col h-[calc(100vh-64px)] sticky top-16">
      <h2 className="text-xl font-semibold text-gray-800 mb-5">Dashboard</h2>
      
      <div className="mb-5">
        <label className="block text-sm font-medium text-gray-600 mb-1">Current Date</label>
        <div className="flex items-center">
          <Calendar className="h-4 w-4 text-gray-500 mr-2" />
          <input 
            type="date" 
            defaultValue="2025-03-21" 
            onChange={handleDateChange}
            className="w-full p-2 border border-gray-300 rounded text-sm"
          />
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-600 mb-1">Subject Filter</label>
          <select 
            value={subjectFilter}
            onChange={(e) => setSubjectFilter(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded text-sm"
          >
            <option value="all">All Subjects</option>
            {subjects.map((subject) => (
              <option key={subject} value={subject}>{subject}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-600 mb-1">Stage Filter</label>
          <select 
            value={stageFilter}
            onChange={(e) => setStageFilter(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded text-sm"
          >
            <option value="all">All Stages</option>
            {stages.map((stage) => (
              <option key={stage} value={stage}>{stage}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-600 mb-1">Rating Filter</label>
          <select 
            value={ratingFilter}
            onChange={(e) => setRatingFilter(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded text-sm"
          >
            <option value="all">All Ratings</option>
            <option value="Hero">Hero</option>
            <option value="Steady">Steady</option>
            <option value="Low">Low</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-600 mb-1">Sort By</label>
          <select 
            value={sortFilter}
            onChange={(e) => setSortFilter(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded text-sm"
          >
            <option value="overall-desc">Performance (High to Low)</option>
            <option value="overall-asc">Performance (Low to High)</option>
            <option value="name-asc">Name (A-Z)</option>
            <option value="name-desc">Name (Z-A)</option>
          </select>
        </div>

        <button
          onClick={handleFilterChange}
          className="w-full bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 transition-colors"
        >
          Apply Filters
        </button>
      </div>

      <div className="mt-8 border-t pt-5">
        <h3 className="text-md font-medium text-gray-700 mb-3">Management</h3>
        <ul className="space-y-2">
          <li>
            <button
              onClick={() => onTabChange('dashboard')}
              className={`w-full text-left px-3 py-2 rounded flex items-center ${
                activeTab === 'dashboard' ? 'bg-blue-100 text-blue-700' : 'hover:bg-gray-100'
              }`}
            >
              Dashboard
            </button>
          </li>
          <li>
            <button
              onClick={() => onTabChange('settings')}
              className={`w-full text-left px-3 py-2 rounded flex items-center ${
                activeTab === 'settings' ? 'bg-blue-100 text-blue-700' : 'hover:bg-gray-100'
              }`}
            >
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </button>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Sidebar;
