
import { motion } from 'framer-motion';
import { Clock } from 'lucide-react';

interface DashboardHeaderProps {
  currentDate: string;
  currentTime: Date;
}

const DashboardHeader = ({ currentDate, currentTime }: DashboardHeaderProps) => {
  return (
    <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-2">
      <div>
        <h2 className="text-2xl font-bold text-gray-800">Dashboard Overview</h2>
        <p className="text-gray-600">
          Current Date: {new Date(currentDate).toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </p>
      </div>
      <motion.div 
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="bg-white p-2 rounded-lg shadow-sm flex items-center gap-2"
      >
        <Clock size={18} className="text-blue-600" />
        <span className="font-medium">
          {currentTime.toLocaleTimeString()}
        </span>
      </motion.div>
    </div>
  );
};

export default DashboardHeader;
