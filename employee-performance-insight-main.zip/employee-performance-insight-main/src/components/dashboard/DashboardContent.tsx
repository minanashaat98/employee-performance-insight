
import DashboardHeader from './DashboardHeader';
import DashboardWidgets from './DashboardWidgets';
import EmployeeTable from './EmployeeTable';

interface DashboardContentProps {
  currentDate: string;
  currentTime: Date;
  filteredEmployees: any[];
}

const DashboardContent = ({
  currentDate,
  currentTime,
  filteredEmployees
}: DashboardContentProps) => {
  return (
    <div className="space-y-6 animate-fade-in">
      <DashboardHeader currentDate={currentDate} currentTime={currentTime} />
      
      <DashboardWidgets employees={filteredEmployees} />
      
      <div>
        <h2 className="text-xl font-bold text-gray-800 mb-2">Employee Performance</h2>
        <p className="text-gray-600 mb-4">Showing {filteredEmployees.length} employees</p>
        <div className="bg-white rounded-lg shadow-md overflow-hidden transition-all hover:shadow-lg">
          <EmployeeTable employees={filteredEmployees} />
        </div>
      </div>
    </div>
  );
};

export default DashboardContent;
