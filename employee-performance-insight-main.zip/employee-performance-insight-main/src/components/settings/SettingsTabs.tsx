
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import { 
  Users, 
  Layers, 
  BookOpen, 
  Calendar, 
  Settings as SettingsIcon, 
  FileEdit 
} from "lucide-react";

import ManageEmployees from './ManageEmployees';
import ManageStages from './ManageStages';
import ManageSubjects from './ManageSubjects';
import ManageSchedules from './ManageSchedules';
import TaskSettings from './TaskSettings';
import EditRequests from './EditRequests';

interface SettingsTabsProps {
  isSaving: boolean;
  onSave: (settingType: string) => Promise<void>;
}

const SettingsTabs = ({ isSaving, onSave }: SettingsTabsProps) => {
  return (
    <Tabs defaultValue="employees" className="w-full">
      <TabsList className="grid grid-cols-3 md:grid-cols-6 gap-2 mb-6">
        <TabsTrigger value="employees" className="flex items-center gap-2">
          <Users size={16} />
          <span className="hidden sm:inline">Employees</span>
        </TabsTrigger>
        <TabsTrigger value="stages" className="flex items-center gap-2">
          <Layers size={16} />
          <span className="hidden sm:inline">Stages</span>
        </TabsTrigger>
        <TabsTrigger value="subjects" className="flex items-center gap-2">
          <BookOpen size={16} />
          <span className="hidden sm:inline">Subjects</span>
        </TabsTrigger>
        <TabsTrigger value="schedules" className="flex items-center gap-2">
          <Calendar size={16} />
          <span className="hidden sm:inline">Schedules</span>
        </TabsTrigger>
        <TabsTrigger value="tasks" className="flex items-center gap-2">
          <SettingsIcon size={16} />
          <span className="hidden sm:inline">Tasks</span>
        </TabsTrigger>
        <TabsTrigger value="requests" className="flex items-center gap-2">
          <FileEdit size={16} />
          <span className="hidden sm:inline">Requests</span>
        </TabsTrigger>
      </TabsList>

      <div className="mb-8">
        <TabsContent value="employees">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <ManageEmployees />
          </motion.div>
        </TabsContent>
        <TabsContent value="stages">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <ManageStages />
          </motion.div>
        </TabsContent>
        <TabsContent value="subjects">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <ManageSubjects />
          </motion.div>
        </TabsContent>
        <TabsContent value="schedules">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <ManageSchedules />
          </motion.div>
        </TabsContent>
        <TabsContent value="tasks">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <TaskSettings onSave={() => onSave('task')} isSaving={isSaving} />
          </motion.div>
        </TabsContent>
        <TabsContent value="requests">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <EditRequests />
          </motion.div>
        </TabsContent>
      </div>
    </Tabs>
  );
};

export default SettingsTabs;
