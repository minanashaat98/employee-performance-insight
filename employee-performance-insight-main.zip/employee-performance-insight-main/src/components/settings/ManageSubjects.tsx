
import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { Plus, Edit, Trash } from 'lucide-react';
import { toast } from "@/hooks/use-toast";

const ManageSubjects = () => {
  const [subjectName, setSubjectName] = useState('');
  const [editingSubject, setEditingSubject] = useState<string | null>(null);

  const { subjects, addSubject, updateSubject, deleteSubject } = useAppStore(
    state => ({
      subjects: state.subjects,
      addSubject: state.addSubject,
      updateSubject: state.updateSubject,
      deleteSubject: state.deleteSubject
    })
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!subjectName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a subject name",
        variant: "destructive"
      });
      return;
    }

    // Check for duplicate
    if (!editingSubject && subjects.includes(subjectName)) {
      toast({
        title: "Error",
        description: "This subject already exists",
        variant: "destructive"
      });
      return;
    }

    if (editingSubject) {
      updateSubject(editingSubject, subjectName);
      setEditingSubject(null);
      toast({
        title: "Success",
        description: "Subject updated successfully",
      });
    } else {
      addSubject(subjectName);
      toast({
        title: "Success",
        description: "Subject added successfully",
      });
    }

    setSubjectName('');
  };

  const handleEdit = (subject: string) => {
    setSubjectName(subject);
    setEditingSubject(subject);
  };

  const handleDelete = (subject: string) => {
    if (window.confirm('Are you sure you want to delete this subject?')) {
      const success = deleteSubject(subject);
      
      if (success) {
        toast({
          title: "Success",
          description: "Subject deleted successfully",
        });
      } else {
        toast({
          title: "Error",
          description: "Cannot delete this subject because it is assigned to one or more employees or has a schedule",
          variant: "destructive"
        });
      }
    }
  };

  const handleCancel = () => {
    setSubjectName('');
    setEditingSubject(null);
  };

  return (
    <div className="bg-white rounded-lg shadow p-6 mt-8">
      <h2 className="text-xl font-semibold mb-6">Manage Subjects</h2>
      
      <form onSubmit={handleSubmit} className="mb-8 flex items-end gap-2">
        <div className="flex-1">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Subject Name
          </label>
          <input
            type="text"
            value={subjectName}
            onChange={(e) => setSubjectName(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded"
            placeholder="Enter subject name"
          />
        </div>
        
        <button
          type="submit"
          className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 flex items-center"
        >
          {editingSubject ? (
            <>
              <Edit className="h-4 w-4 mr-2" />
              Update Subject
            </>
          ) : (
            <>
              <Plus className="h-4 w-4 mr-2" />
              Add Subject
            </>
          )}
        </button>
        
        {editingSubject && (
          <button
            type="button"
            onClick={handleCancel}
            className="bg-gray-300 text-gray-800 py-2 px-4 rounded hover:bg-gray-400"
          >
            Cancel
          </button>
        )}
      </form>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {subjects.map((subject) => (
              <tr key={subject}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{subject}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button
                    onClick={() => handleEdit(subject)}
                    className="text-blue-600 hover:text-blue-900 mr-3"
                  >
                    <Edit className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(subject)}
                    className="text-red-600 hover:text-red-900"
                  >
                    <Trash className="h-4 w-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ManageSubjects;
