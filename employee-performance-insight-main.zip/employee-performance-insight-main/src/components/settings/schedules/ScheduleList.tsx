
import React from 'react';
import { Edit, Trash } from 'lucide-react';
import { useAppStore } from '@/lib/store';
import { SubjectSchedule } from '@/lib/types';
import { toast } from "@/hooks/use-toast";

interface ScheduleListProps {
  onEditSchedule: (schedule: SubjectSchedule) => void;
}

const ScheduleList: React.FC<ScheduleListProps> = ({ onEditSchedule }) => {
  const { subjectSchedules, deleteSubjectSchedule } = useAppStore(
    state => ({
      subjectSchedules: state.subjectSchedules,
      deleteSubjectSchedule: state.deleteSubjectSchedule
    })
  );

  const handleDelete = (subject: string) => {
    if (window.confirm('Are you sure you want to delete this schedule?')) {
      deleteSubjectSchedule(subject);
      toast({
        title: "Success",
        description: "Schedule deleted successfully"
      });
    }
  };

  return (
    <div className="overflow-x-auto">
      <h3 className="text-lg font-medium mb-3">Current Schedules</h3>
      <table className="min-w-full divide-y divide-gray-200">
        <thead>
          <tr className="bg-gray-50">
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sessions</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {subjectSchedules.length === 0 ? (
            <tr>
              <td colSpan={3} className="px-6 py-4 text-center text-sm text-gray-500">
                No schedules defined yet
              </td>
            </tr>
          ) : (
            subjectSchedules.map((schedule) => (
              <tr key={schedule.subject}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {schedule.subject}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {schedule.sessions}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button
                    onClick={() => onEditSchedule(schedule)}
                    className="text-blue-600 hover:text-blue-900 mr-3"
                  >
                    <Edit className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(schedule.subject)}
                    className="text-red-600 hover:text-red-900"
                  >
                    <Trash className="h-4 w-4" />
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ScheduleList;
