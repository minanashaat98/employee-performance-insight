
import React, { useState, useEffect } from 'react';
import { Plus, Edit } from 'lucide-react';
import { toast } from "@/hooks/use-toast";
import { useAppStore } from '@/lib/store';
import { SubjectSchedule } from '@/lib/types';
import SessionDateInputs from './SessionDateInputs';

interface ScheduleFormProps {
  editingSchedule: SubjectSchedule | null;
  onCancelEdit: () => void;
}

const ScheduleForm: React.FC<ScheduleFormProps> = ({ 
  editingSchedule, 
  onCancelEdit 
}) => {
  const [subject, setSubject] = useState('');
  const [sessionsCount, setSessionsCount] = useState(12);
  const [dates, setDates] = useState<string[]>([]);

  const { subjects, addSubjectSchedule } = useAppStore(
    state => ({
      subjects: state.subjects,
      addSubjectSchedule: state.addSubjectSchedule
    })
  );

  // Update form when editing a schedule
  useEffect(() => {
    if (editingSchedule) {
      setSubject(editingSchedule.subject);
      setSessionsCount(editingSchedule.sessions);
      setDates([...editingSchedule.dates]);
    }
  }, [editingSchedule]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!subject) {
      toast({
        title: "Error",
        description: "Please select a subject",
        variant: "destructive"
      });
      return;
    }

    if (sessionsCount <= 0) {
      toast({
        title: "Error",
        description: "Please enter a valid number of sessions",
        variant: "destructive"
      });
      return;
    }

    // Check that all dates are filled in
    const validDates = dates.slice(0, sessionsCount);
    if (validDates.length < sessionsCount || validDates.some(date => !date)) {
      toast({
        title: "Error",
        description: "Please enter dates for all sessions",
        variant: "destructive"
      });
      return;
    }

    addSubjectSchedule({
      subject,
      sessions: sessionsCount,
      dates: validDates
    });

    toast({
      title: "Success",
      description: editingSchedule ? "Schedule updated successfully" : "Schedule added successfully"
    });

    // Reset form
    setSubject('');
    setSessionsCount(12);
    setDates([]);
    onCancelEdit();
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Subject
        </label>
        <select
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          className="w-full p-2 border border-gray-300 rounded"
        >
          <option value="">Select a subject</option>
          {subjects.map((sub) => (
            <option key={sub} value={sub}>{sub}</option>
          ))}
        </select>
      </div>
      
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Number of Sessions
        </label>
        <input
          type="number"
          value={sessionsCount}
          onChange={(e) => {
            const value = parseInt(e.target.value);
            setSessionsCount(value > 0 ? value : 0);
          }}
          className="w-full p-2 border border-gray-300 rounded"
          min="1"
        />
      </div>
      
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-3">
          Session Dates
        </label>
        <SessionDateInputs 
          sessionsCount={sessionsCount} 
          dates={dates} 
          onDateChange={setDates} 
        />
      </div>
      
      <div className="flex gap-2">
        <button
          type="submit"
          className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 flex items-center"
        >
          {editingSchedule ? (
            <>
              <Edit className="h-4 w-4 mr-2" />
              Update Schedule
            </>
          ) : (
            <>
              <Plus className="h-4 w-4 mr-2" />
              Add Schedule
            </>
          )}
        </button>
        
        {editingSchedule && (
          <button
            type="button"
            onClick={onCancelEdit}
            className="bg-gray-300 text-gray-800 py-2 px-4 rounded hover:bg-gray-400"
          >
            Cancel
          </button>
        )}
      </div>
    </form>
  );
};

export default ScheduleForm;
