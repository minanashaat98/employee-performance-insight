
import React from 'react';

interface SessionDateInputsProps {
  sessionsCount: number;
  dates: string[];
  onDateChange: (newDates: string[]) => void;
}

const SessionDateInputs: React.FC<SessionDateInputsProps> = ({ 
  sessionsCount, 
  dates, 
  onDateChange 
}) => {
  const handleDateChange = (index: number, value: string) => {
    const newDates = [...dates];
    newDates[index] = value;
    onDateChange(newDates);
  };

  const inputs = [];
  for (let i = 0; i < sessionsCount; i++) {
    inputs.push(
      <div key={i} className="mb-2 flex items-center">
        <label className="text-sm font-medium text-gray-700 mr-2 w-24">
          Session {i + 1}:
        </label>
        <input
          type="date"
          value={dates[i] || ''}
          onChange={(e) => handleDateChange(i, e.target.value)}
          className="p-2 border border-gray-300 rounded"
        />
      </div>
    );
  }

  return (
    <div className="border border-gray-200 rounded p-4 max-h-80 overflow-y-auto">
      {inputs}
    </div>
  );
};

export default SessionDateInputs;
