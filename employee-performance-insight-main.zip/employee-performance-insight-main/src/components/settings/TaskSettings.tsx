
import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface TaskSettingsProps {
  isSaving: boolean;
  onSave: () => Promise<void>;
}

const TaskSettings = ({ isSaving, onSave }: TaskSettingsProps) => {
  const { taskSettings, updateTaskSettings } = useAppStore(state => ({
    taskSettings: state.taskSettings,
    updateTaskSettings: state.updateTaskSettings
  }));
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    examsCount: taskSettings.examsRecordedCount,
    modelExamsCount: taskSettings.modelExamsCount,
    summariesCount: taskSettings.whatsappChatsCount
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: parseInt(value, 10) || 0
    });
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      updateTaskSettings({
        examsRecordedCount: formData.examsCount,
        modelExamsCount: formData.modelExamsCount,
        whatsappChatsCount: formData.summariesCount
      });
      await onSave();
      
      toast({
        title: "Settings Updated",
        description: "Task settings have been updated successfully.",
      });
    } catch (error) {
      toast({
        title: "Update Failed",
        description: "Failed to update task settings.",
        variant: "destructive"
      });
      console.error('Error updating task settings:', error);
    }
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Task Settings</CardTitle>
        <CardDescription>Configure the number of tasks required for each category</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <label htmlFor="examsCount" className="text-sm font-medium">
                Exams Count
              </label>
              <input
                id="examsCount"
                name="examsCount"
                type="number"
                min="1"
                value={formData.examsCount}
                onChange={handleChange}
                className="w-full p-2 border border-gray-300 rounded"
              />
              <p className="text-xs text-gray-500">Number of regular exams required</p>
            </div>
            
            <div className="space-y-2">
              <label htmlFor="modelExamsCount" className="text-sm font-medium">
                Model Exams Count
              </label>
              <input
                id="modelExamsCount"
                name="modelExamsCount"
                type="number"
                min="1"
                value={formData.modelExamsCount}
                onChange={handleChange}
                className="w-full p-2 border border-gray-300 rounded"
              />
              <p className="text-xs text-gray-500">Number of model exams required</p>
            </div>
            
            <div className="space-y-2">
              <label htmlFor="summariesCount" className="text-sm font-medium">
                Summaries Count
              </label>
              <input
                id="summariesCount"
                name="summariesCount"
                type="number"
                min="1"
                value={formData.summariesCount}
                onChange={handleChange}
                className="w-full p-2 border border-gray-300 rounded"
              />
              <p className="text-xs text-gray-500">Number of summaries required</p>
            </div>
          </div>
          
          <div className="flex justify-end">
            <Button 
              type="submit" 
              disabled={isSaving}
              className="flex items-center gap-2"
            >
              {isSaving && (
                <span className="h-4 w-4 rounded-full border-2 border-b-transparent border-white animate-spin"></span>
              )}
              Save Settings
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default TaskSettings;
