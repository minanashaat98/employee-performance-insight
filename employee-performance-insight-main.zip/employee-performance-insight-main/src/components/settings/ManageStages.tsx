
import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { Plus, Edit, Trash } from 'lucide-react';
import { toast } from "@/hooks/use-toast";

const ManageStages = () => {
  const [stageName, setStageName] = useState('');
  const [editingStage, setEditingStage] = useState<string | null>(null);

  const { stages, addStage, updateStage, deleteStage } = useAppStore(
    state => ({
      stages: state.stages,
      addStage: state.addStage,
      updateStage: state.updateStage,
      deleteStage: state.deleteStage
    })
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!stageName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a stage name",
        variant: "destructive"
      });
      return;
    }

    // Check for duplicate
    if (!editingStage && stages.includes(stageName)) {
      toast({
        title: "Error",
        description: "This stage already exists",
        variant: "destructive"
      });
      return;
    }

    if (editingStage) {
      updateStage(editingStage, stageName);
      setEditingStage(null);
      toast({
        title: "Success",
        description: "Stage updated successfully",
      });
    } else {
      addStage(stageName);
      toast({
        title: "Success",
        description: "Stage added successfully",
      });
    }

    setStageName('');
  };

  const handleEdit = (stage: string) => {
    setStageName(stage);
    setEditingStage(stage);
  };

  const handleDelete = (stage: string) => {
    if (window.confirm('Are you sure you want to delete this stage?')) {
      const success = deleteStage(stage);
      
      if (success) {
        toast({
          title: "Success",
          description: "Stage deleted successfully",
        });
      } else {
        toast({
          title: "Error",
          description: "Cannot delete this stage because it is assigned to one or more employees",
          variant: "destructive"
        });
      }
    }
  };

  const handleCancel = () => {
    setStageName('');
    setEditingStage(null);
  };

  return (
    <div className="bg-white rounded-lg shadow p-6 mt-8">
      <h2 className="text-xl font-semibold mb-6">Manage Stages</h2>
      
      <form onSubmit={handleSubmit} className="mb-8 flex items-end gap-2">
        <div className="flex-1">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Stage Name
          </label>
          <input
            type="text"
            value={stageName}
            onChange={(e) => setStageName(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded"
            placeholder="Enter stage name"
          />
        </div>
        
        <button
          type="submit"
          className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 flex items-center"
        >
          {editingStage ? (
            <>
              <Edit className="h-4 w-4 mr-2" />
              Update Stage
            </>
          ) : (
            <>
              <Plus className="h-4 w-4 mr-2" />
              Add Stage
            </>
          )}
        </button>
        
        {editingStage && (
          <button
            type="button"
            onClick={handleCancel}
            className="bg-gray-300 text-gray-800 py-2 px-4 rounded hover:bg-gray-400"
          >
            Cancel
          </button>
        )}
      </form>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stage Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {stages.map((stage) => (
              <tr key={stage}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{stage}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button
                    onClick={() => handleEdit(stage)}
                    className="text-blue-600 hover:text-blue-900 mr-3"
                  >
                    <Edit className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(stage)}
                    className="text-red-600 hover:text-red-900"
                  >
                    <Trash className="h-4 w-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ManageStages;
