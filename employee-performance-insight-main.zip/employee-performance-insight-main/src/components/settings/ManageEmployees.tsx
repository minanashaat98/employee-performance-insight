
import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { Plus, Edit, Trash, Check, X } from 'lucide-react';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from '@/components/ui/badge';

const ManageEmployees = () => {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('123456');
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>([]);
  const [selectedStage, setSelectedStage] = useState('');
  const [editingEmployee, setEditingEmployee] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showSubjectDropdown, setShowSubjectDropdown] = useState(false);
  const { toast } = useToast();

  const { employees, subjects, stages, addEmployee, updateEmployee, deleteEmployee } = useAppStore(
    state => ({
      employees: state.employees,
      subjects: state.subjects,
      stages: state.stages,
      addEmployee: state.addEmployee,
      updateEmployee: state.updateEmployee,
      deleteEmployee: state.deleteEmployee
    })
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    if (!name || selectedSubjects.length === 0 || !selectedStage) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      setIsLoading(false);
      return;
    }

    try {
      if (editingEmployee) {
        updateEmployee(editingEmployee, {
          name,
          username: username.toUpperCase(),
          password,
          subjects: selectedSubjects,
          stage: selectedStage
        });
        toast({
          title: "Success",
          description: "Employee updated successfully",
        });
        setEditingEmployee(null);
      } else {
        addEmployee({
          name,
          username: username.toUpperCase(),
          password,
          subjects: selectedSubjects,
          stage: selectedStage,
        } as any);
        toast({
          title: "Success",
          description: "Employee added successfully",
        });
      }

      // Reset form
      setName('');
      setUsername('');
      setPassword('123456');
      setSelectedSubjects([]);
      setSelectedStage('');
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save employee data",
        variant: "destructive"
      });
      console.error("Employee save error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEdit = (employee: any) => {
    setName(employee.name);
    setUsername(employee.username);
    setPassword(employee.password);
    setSelectedSubjects(employee.subjects);
    setSelectedStage(employee.stage);
    setEditingEmployee(employee.id);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this employee?')) {
      try {
        deleteEmployee(id);
        toast({
          title: "Success",
          description: "Employee deleted successfully",
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to delete employee",
          variant: "destructive"
        });
      }
    }
  };

  const handleCancel = () => {
    setName('');
    setUsername('');
    setPassword('123456');
    setSelectedSubjects([]);
    setSelectedStage('');
    setEditingEmployee(null);
  };

  const handleAddSubject = (subject: string) => {
    if (!selectedSubjects.includes(subject)) {
      setSelectedSubjects([...selectedSubjects, subject]);
    }
  };

  const handleRemoveSubject = (subject: string) => {
    setSelectedSubjects(selectedSubjects.filter(s => s !== subject));
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-semibold mb-6">Manage Employees</h2>
      
      <form onSubmit={handleSubmit} className="mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Name*
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (!editingEmployee) setUsername(e.target.value);
              }}
              className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Username*
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Password
            </label>
            <input
              type="text"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Stage*
            </label>
            <Select 
              value={selectedStage} 
              onValueChange={(value) => setSelectedStage(value)}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select a stage" />
              </SelectTrigger>
              <SelectContent>
                {stages.map((stage) => (
                  <SelectItem key={stage} value={stage}>{stage}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Subjects* <span className="text-xs text-gray-500">(Select at least one)</span>
            </label>
            <div className="relative">
              <div className="flex flex-wrap gap-2 p-2 min-h-12 border border-gray-300 rounded mb-2">
                {selectedSubjects.length === 0 && (
                  <span className="text-gray-400 text-sm">No subjects selected</span>
                )}
                {selectedSubjects.map(subject => (
                  <Badge key={subject} className="flex items-center gap-1 bg-blue-100 text-blue-800 hover:bg-blue-200">
                    {subject}
                    <button 
                      type="button" 
                      onClick={() => handleRemoveSubject(subject)}
                      className="ml-1 text-blue-600 hover:text-blue-800"
                    >
                      <X size={14} />
                    </button>
                  </Badge>
                ))}
              </div>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button 
                    type="button"
                    className="px-3 py-1 text-sm bg-blue-50 text-blue-600 border border-blue-200 rounded hover:bg-blue-100"
                  >
                    Add Subject
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56">
                  <DropdownMenuLabel>Available Subjects</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {subjects.length === 0 ? (
                    <DropdownMenuItem disabled>No subjects available</DropdownMenuItem>
                  ) : (
                    subjects.map(subject => (
                      <DropdownMenuItem 
                        key={subject}
                        onClick={() => handleAddSubject(subject)}
                        disabled={selectedSubjects.includes(subject)}
                        className="flex items-center justify-between"
                      >
                        {subject}
                        {selectedSubjects.includes(subject) && <Check className="h-4 w-4 text-green-500" />}
                      </DropdownMenuItem>
                    ))
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
        
        <div className="flex mt-4 gap-2">
          <button
            type="submit"
            disabled={isLoading}
            className={`bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 flex items-center ${isLoading ? 'opacity-70 cursor-not-allowed' : ''}`}
          >
            {isLoading ? (
              <>
                <span className="animate-spin h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full"></span>
                {editingEmployee ? 'Updating...' : 'Adding...'}
              </>
            ) : editingEmployee ? (
              <>
                <Edit className="h-4 w-4 mr-2" />
                Update Employee
              </>
            ) : (
              <>
                <Plus className="h-4 w-4 mr-2" />
                Add Employee
              </>
            )}
          </button>
          
          {editingEmployee && (
            <button
              type="button"
              onClick={handleCancel}
              className="bg-gray-300 text-gray-800 py-2 px-4 rounded hover:bg-gray-400"
            >
              Cancel
            </button>
          )}
        </div>
      </form>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Username</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stage</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subjects</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {employees.map((employee) => (
              <tr key={employee.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{employee.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{employee.username}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{employee.stage}</td>
                <td className="px-6 py-4 text-sm text-gray-500">
                  <div className="flex flex-wrap gap-1">
                    {employee.subjects.map(subject => (
                      <Badge key={subject} variant="outline" className="bg-gray-100">
                        {subject}
                      </Badge>
                    ))}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button
                    onClick={() => handleEdit(employee)}
                    className="text-blue-600 hover:text-blue-900 mr-3"
                  >
                    <Edit className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(employee.id)}
                    className="text-red-600 hover:text-red-900"
                  >
                    <Trash className="h-4 w-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ManageEmployees;
