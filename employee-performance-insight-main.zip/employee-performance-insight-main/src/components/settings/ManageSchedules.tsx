
import { useState } from 'react';
import { SubjectSchedule } from '@/lib/types';
import ScheduleForm from './schedules/ScheduleForm';
import ScheduleList from './schedules/ScheduleList';

const ManageSchedules = () => {
  const [editingSchedule, setEditingSchedule] = useState<SubjectSchedule | null>(null);

  const handleEditSchedule = (schedule: SubjectSchedule) => {
    setEditingSchedule(schedule);
  };

  const handleCancelEdit = () => {
    setEditingSchedule(null);
  };

  return (
    <div className="bg-white rounded-lg shadow p-6 mt-8">
      <h2 className="text-xl font-semibold mb-6">Manage Schedules</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div>
          <ScheduleForm 
            editingSchedule={editingSchedule} 
            onCancelEdit={handleCancelEdit} 
          />
        </div>
        
        <ScheduleList onEditSchedule={handleEditSchedule} />
      </div>
    </div>
  );
};

export default ManageSchedules;
