
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { useAppStore } from '@/lib/store';
import { useToast } from '@/components/ui/use-toast';
import DataEntryNotifications from './dataentry/DataEntryNotifications';

interface HeaderProps {
  title?: string;
}

const Header = ({ title = 'Employee Management System' }: HeaderProps) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const { currentUser, isAdmin, isDataEntry, logout } = useAppStore(state => ({
    currentUser: state.currentUser,
    isAdmin: state.isAdmin,
    isDataEntry: state.isDataEntry,
    logout: state.logout
  }));
  
  const handleLogout = () => {
    logout();
    navigate('/');
    toast({
      title: "Logged Out",
      description: "You have been successfully logged out.",
      duration: 2000
    });
  };
  
  return (
    <nav className="bg-white shadow" dir="ltr">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <span className="text-lg font-bold text-gray-800">{title}</span>
            </div>
            
            {/* Desktop navigation */}
            {currentUser && (
              <div className="hidden sm:ml-6 sm:flex sm:items-center sm:space-x-4">
                {isAdmin && (
                  <Link 
                    to="/dashboard"
                    className="px-3 py-2 text-sm font-medium text-gray-700 hover:text-gray-900 rounded-md hover:bg-gray-100"
                  >
                    Admin Dashboard
                  </Link>
                )}
                
                {isDataEntry && (
                  <Link 
                    to="/dataentry"
                    className="px-3 py-2 text-sm font-medium text-gray-700 hover:text-gray-900 rounded-md hover:bg-gray-100"
                  >
                    Data Entry Dashboard
                  </Link>
                )}
                
                <Link 
                  to="/employee"
                  className="px-3 py-2 text-sm font-medium text-gray-700 hover:text-gray-900 rounded-md hover:bg-gray-100"
                >
                  Employee Area
                </Link>
              </div>
            )}
          </div>
          
          <div className="flex items-center">
            {currentUser && isDataEntry && (
              <div className="mx-4">
                <DataEntryNotifications />
              </div>
            )}
            
            {currentUser && (
              <button
                onClick={handleLogout}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
              >
                Logout
              </button>
            )}
            
            {/* Mobile menu button */}
            <div className="flex items-center sm:hidden ml-2">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100"
              >
                {mobileMenuOpen ? (
                  <X className="block h-6 w-6" />
                ) : (
                  <Menu className="block h-6 w-6" />
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {mobileMenuOpen && currentUser && (
        <div className="sm:hidden" dir="ltr">
          <div className="pt-2 pb-3 space-y-1">
            {isAdmin && (
              <Link
                to="/dashboard"
                className="block px-3 py-2 text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
                onClick={() => setMobileMenuOpen(false)}
              >
                Admin Dashboard
              </Link>
            )}
            
            {isDataEntry && (
              <Link
                to="/dataentry"
                className="block px-3 py-2 text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
                onClick={() => setMobileMenuOpen(false)}
              >
                Data Entry Dashboard
              </Link>
            )}
            
            <Link
              to="/employee"
              className="block px-3 py-2 text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
              onClick={() => setMobileMenuOpen(false)}
            >
              Employee Area
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Header;
