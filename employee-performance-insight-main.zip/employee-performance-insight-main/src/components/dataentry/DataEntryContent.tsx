
import { useState, useEffect } from 'react';
import { useAppStore } from '@/lib/store';
import { Check, File, Upload, Filter, RefreshCcw, Eye } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  FileUpload, 
  Employee, 
  EmployeeFileType 
} from '@/lib/types';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
} from "@/components/ui/card";

interface DataEntryContentProps {
  status: 'pending' | 'completed';
}

const DataEntryContent = ({ status }: DataEntryContentProps) => {
  const { employees, markFileAsProcessed, fileUploads } = useAppStore(state => ({
    employees: state.employees,
    markFileAsProcessed: state.markFileAsProcessed,
    fileUploads: state.fileUploads
  }));
  const { toast } = useToast();

  const [filteredUploads, setFilteredUploads] = useState<FileUpload[]>([]);
  const [stageFilter, setStageFilter] = useState<string>('all');
  const [subjectFilter, setSubjectFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [isFiltering, setIsFiltering] = useState(false);

  // Get unique stages and subjects for filters
  const stages = ['all', ...new Set(employees.map(emp => emp.stage))];
  const subjects = ['all', ...new Set(employees.flatMap(emp => emp.subjects))];

  // Filter uploads based on status and filters
  useEffect(() => {
    const filtered = fileUploads.filter(upload => {
      const stageMatch = stageFilter === 'all' || upload.stage === stageFilter;
      const subjectMatch = subjectFilter === 'all' || upload.subject === subjectFilter;
      const searchMatch = searchTerm === '' || 
        upload.employeeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        upload.subject.toLowerCase().includes(searchTerm.toLowerCase());
      const statusMatch = status === 'pending' ? !upload.processed : upload.processed;
      return stageMatch && subjectMatch && statusMatch && searchMatch;
    });
    
    setFilteredUploads(filtered);
  }, [fileUploads, status, stageFilter, subjectFilter, searchTerm]);

  const handleMarkAsProcessed = (uploadId: string) => {
    markFileAsProcessed(uploadId);
    toast({
      title: "File Processed",
      description: "File has been marked as processed",
      duration: 2000,
    });
  };

  const resetFilters = () => {
    setStageFilter('all');
    setSubjectFilter('all');
    setSearchTerm('');
    setIsFiltering(false);
  };

  const getFileTypeLabel = (type: EmployeeFileType) => {
    switch (type) {
      case 'exam':
        return 'Exam';
      case 'modelExam':
        return 'Model Exam';
      case 'paperSummary':
        return 'Paper Summary';
      case 'finalPaperSummary':
        return 'Final Paper Summary';
      default:
        return 'Unknown';
    }
  };

  const getFileTypeColor = (type: EmployeeFileType) => {
    switch (type) {
      case 'exam':
        return 'bg-blue-100 text-blue-800';
      case 'modelExam':
        return 'bg-purple-100 text-purple-800';
      case 'paperSummary':
        return 'bg-amber-100 text-amber-800';
      case 'finalPaperSummary':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="relative">
          <Input
            placeholder="Search by employee or subject..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 w-full sm:w-64"
          />
          <Eye className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>
        
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setIsFiltering(!isFiltering)}
            className="flex items-center gap-2"
          >
            <Filter className="h-4 w-4" />
            {isFiltering ? "Hide Filters" : "Show Filters"}
          </Button>
          
          {(stageFilter !== 'all' || subjectFilter !== 'all' || searchTerm !== '') && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={resetFilters}
              className="flex items-center gap-2"
            >
              <RefreshCcw className="h-4 w-4" />
              Reset
            </Button>
          )}
        </div>
      </div>

      {isFiltering && (
        <Card className="border border-gray-200 shadow-sm">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Stage</label>
                <select
                  value={stageFilter}
                  onChange={(e) => setStageFilter(e.target.value)}
                  className="w-full p-2 border rounded-md text-sm bg-white"
                >
                  {stages.map((stage) => (
                    <option key={stage} value={stage}>
                      {stage === 'all' ? 'All Stages' : stage}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Subject</label>
                <select
                  value={subjectFilter}
                  onChange={(e) => setSubjectFilter(e.target.value)}
                  className="w-full p-2 border rounded-md text-sm bg-white"
                >
                  {subjects.map((subject) => (
                    <option key={subject} value={subject}>
                      {subject === 'all' ? 'All Subjects' : subject}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {filteredUploads.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg border border-dashed border-gray-300">
          <Upload className="mx-auto h-12 w-12 text-gray-400" />
          <p className="mt-4 text-lg font-medium text-gray-900">No files found</p>
          <p className="mt-1 text-gray-500">
            No {status} files found with the current filters
          </p>
          {(stageFilter !== 'all' || subjectFilter !== 'all' || searchTerm !== '') && (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={resetFilters}
              className="mt-4"
            >
              Clear filters
            </Button>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-lg overflow-hidden border shadow">
          <Table>
            <TableHeader className="bg-gray-50">
              <TableRow>
                <TableHead className="font-medium">Employee</TableHead>
                <TableHead className="font-medium">File Type</TableHead>
                <TableHead className="font-medium">Subject</TableHead>
                <TableHead className="font-medium">Stage</TableHead>
                <TableHead className="font-medium">Uploaded</TableHead>
                <TableHead className="font-medium">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUploads.map((upload) => (
                <TableRow key={upload.id} className="hover:bg-gray-50">
                  <TableCell className="font-medium">{upload.employeeName}</TableCell>
                  <TableCell>
                    <Badge className={getFileTypeColor(upload.fileType)}>
                      {getFileTypeLabel(upload.fileType)}
                    </Badge>
                  </TableCell>
                  <TableCell>{upload.subject}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{upload.stage}</Badge>
                  </TableCell>
                  <TableCell className="text-gray-500 text-sm">
                    {new Date(upload.timestamp).toLocaleDateString()} at {new Date(upload.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <a 
                        href={upload.fileURL} 
                        target="_blank" 
                        rel="noreferrer" 
                        className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1 transition-colors"
                      >
                        <File className="h-4 w-4" />
                        View
                      </a>
                      
                      {status === 'pending' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleMarkAsProcessed(upload.id)}
                          className="ml-2 flex items-center gap-1 text-green-600 hover:text-green-800 hover:bg-green-50 border-green-200"
                        >
                          <Check className="h-4 w-4" />
                          Process
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
            <TableCaption>
              Showing {filteredUploads.length} {status} files
            </TableCaption>
          </Table>
        </div>
      )}
    </div>
  );
};

export default DataEntryContent;
