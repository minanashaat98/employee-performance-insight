
import { useState, useEffect } from 'react';
import { useAppStore } from '@/lib/store';
import { Bell, File, UserIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { FileUpload } from '@/lib/types';
import { useToast } from '@/components/ui/use-toast';
import { AnimatePresence, motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';

const DataEntryNotifications = () => {
  const { fileUploads, markFileAsViewed } = useAppStore(state => ({
    fileUploads: state.fileUploads,
    markFileAsViewed: state.markFileAsViewed
  }));
  const { toast } = useToast();
  
  const [unviewedUploads, setUnviewedUploads] = useState<FileUpload[]>([]);
  const [animation, setAnimation] = useState(false);

  useEffect(() => {
    const unviewed = fileUploads.filter(upload => !upload.viewed && !upload.processed);
    setUnviewedUploads(unviewed);
    
    // Add animation if there are new uploads
    if (unviewed.length > 0) {
      setAnimation(true);
      const timer = setTimeout(() => setAnimation(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [fileUploads]);

  const handleViewAll = () => {
    unviewedUploads.forEach(upload => {
      markFileAsViewed(upload.id);
    });
    
    toast({
      title: "All Notifications Viewed",
      description: "All notifications have been marked as viewed",
      duration: 2000,
    });
  };

  const handleItemClick = (uploadId: string) => {
    markFileAsViewed(uploadId);
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'exam':
        return 'Exam';
      case 'modelExam':
        return 'Model Exam';
      case 'paperSummary':
        return 'Paper Summary';
      case 'finalPaperSummary':
        return 'Final Paper Summary';
      default:
        return type;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'exam':
        return 'bg-blue-500';
      case 'modelExam':
        return 'bg-purple-500';
      case 'paperSummary':
        return 'bg-amber-500';
      case 'finalPaperSummary':
        return 'bg-green-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon" className="relative bg-white hover:bg-gray-50">
          <AnimatePresence>
            {animation && (
              <motion.span
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1.2, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                transition={{ repeat: 5, duration: 0.4 }}
                className="absolute inset-0 rounded-full border-2 border-blue-400"
              />
            )}
          </AnimatePresence>
          <Bell className="h-5 w-5 text-gray-700" />
          {unviewedUploads.length > 0 && (
            <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
              {unviewedUploads.length}
            </span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <DropdownMenuLabel className="flex items-center justify-between bg-gray-50 py-3">
          <span className="font-bold">Notifications</span>
          {unviewedUploads.length > 0 && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleViewAll}
              className="text-xs text-blue-600 hover:text-blue-800 hover:bg-blue-50"
            >
              Mark all as viewed
            </Button>
          )}
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        
        {unviewedUploads.length === 0 ? (
          <div className="p-6 text-center text-gray-500">
            <Bell className="h-8 w-8 text-gray-300 mx-auto mb-2" />
            <p className="text-gray-600 font-medium">No new notifications</p>
            <p className="text-sm">All caught up!</p>
          </div>
        ) : (
          <div className="max-h-[300px] overflow-y-auto">
            {unviewedUploads.map((upload) => (
              <DropdownMenuItem key={upload.id} onClick={() => handleItemClick(upload.id)} className="p-3 cursor-pointer hover:bg-gray-50">
                <div className="flex items-start w-full">
                  <div className={`flex-shrink-0 w-8 h-8 rounded-full ${getTypeColor(upload.fileType)} text-white flex items-center justify-center mr-3`}>
                    <File className="h-4 w-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-gray-900">{upload.employeeName}</span>
                      <span className="text-xs text-gray-500">
                        {new Date(upload.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                      </span>
                    </div>
                    <p className="text-sm text-gray-700 mt-1">
                      Uploaded new {getTypeLabel(upload.fileType)} for {upload.subject}
                    </p>
                    <div className="flex items-center mt-1">
                      <Badge variant="outline" className="mr-1 text-xs">
                        {upload.stage}
                      </Badge>
                      <Badge className={`text-xs ${upload.fileType === 'exam' || upload.fileType === 'modelExam' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'}`}>
                        {getTypeLabel(upload.fileType)}
                      </Badge>
                    </div>
                  </div>
                </div>
              </DropdownMenuItem>
            ))}
          </div>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default DataEntryNotifications;
